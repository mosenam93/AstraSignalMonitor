plugins {
    id("com.android.application")
}

android {
    signingConfigs {
        create("astraRelease") {
            val ksPath = System.getenv("ASTRA_KEYSTORE_PATH")
            if (!ksPath.isNullOrBlank()) {
                storeFile = file(ksPath)
                storePassword = System.getenv("ASTRA_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ASTRA_KEY_ALIAS") ?: "astra"
                keyPassword = System.getenv("ASTRA_KEY_PASSWORD")
            }
        }
    }

    namespace = "com.astra.signalmonitor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.astra.signalmonitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "0.6"
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("astraRelease")
        }
    }
}

dependencies {
    // Bundled OCR model: works on-device and does not need an AI/API key.
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
