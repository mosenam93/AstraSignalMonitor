plugins {
    id("com.android.application")
}

android {
    namespace = "com.astra.signalmonitor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.astra.signalmonitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }
}

dependencies {
    // Bundled OCR model: works on-device and does not need an AI/API key.
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
