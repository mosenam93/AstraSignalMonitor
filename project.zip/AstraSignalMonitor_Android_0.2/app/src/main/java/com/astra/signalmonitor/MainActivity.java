package com.astra.signalmonitor;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.lang.ref.WeakReference;
import java.util.List;

public class MainActivity extends Activity {
    static final String SIGNAL_CHANNEL_ID = "astra_signal_alerts_v2";
    private static final int REQ_RINGTONE = 203;
    private static final int NEW_JUMP_PX = 80;

    private static WeakReference<MainActivity> activeActivity = new WeakReference<>(null);

    private WebView webView;
    private TextView status, lastScan;
    private Button startBtn, stopBtn, historyBtn, alarmBtn;

    private boolean monitoring = false;
    private boolean ocrBusy = false;
    private boolean baselineReady = false;

    private TextRecognizer recognizer;
    private final SignalDetector detector = new SignalDetector();
    private SignalStore store;

    private SignalDetector.Candidate tracked = null;
    private int consecutiveNew = 0;
    private SignalDetector.Candidate pendingNew = null;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        activeActivity = new WeakReference<>(this);
        getWindow().setStatusBarColor(Color.rgb(11,15,20));

        store = new SignalStore(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        createNotificationChannels();
        requestNotificationPermission();
        buildUi();
        configureWebView();

        monitoring = getSharedPreferences("astra_state", MODE_PRIVATE)
                .getBoolean("monitor_active", false);

        webView.loadUrl("https://www.tradingview.com/chart/");
        updateMonitorUi();

        if (monitoring) startMonitorService();
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + .5f);
    }

    private TextView text(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(10,14,19));
        root.setPadding(dp(6), dp(6), dp(6), dp(6));
        root.setClipToPadding(false);
        root.setFitsSystemWindows(true);

        LinearLayout urlRow = new LinearLayout(this);
        urlRow.setOrientation(LinearLayout.HORIZONTAL);

        final EditText url = new EditText(this);
        url.setSingleLine(true);
        url.setText("https://www.tradingview.com/chart/");
        url.setTextColor(Color.WHITE);
        url.setHintTextColor(Color.GRAY);
        url.setTextSize(12);
        url.setPadding(dp(10), 0, dp(8), 0);
        url.setBackgroundColor(Color.rgb(19,26,35));

        Button go = button("GO");
        go.setTextSize(13);
        go.setBackgroundColor(Color.rgb(42,54,68));

        urlRow.addView(url, new LinearLayout.LayoutParams(0, dp(42), 1f));
        LinearLayout.LayoutParams goLp = new LinearLayout.LayoutParams(dp(62), dp(42));
        goLp.leftMargin = dp(6);
        urlRow.addView(go, goLp);
        root.addView(urlRow);

        int screenH = getResources().getDisplayMetrics().heightPixels;
        int browserHeight = Math.max(dp(280), (int)(screenH * 0.56f));

        webView = new WebView(this);
        LinearLayout.LayoutParams webLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, browserHeight);
        webLp.topMargin = dp(5);
        root.addView(webView, webLp);

        LinearLayout state = new LinearLayout(this);
        state.setOrientation(LinearLayout.HORIZONTAL);
        state.setGravity(Gravity.CENTER_VERTICAL);
        state.setPadding(dp(10), dp(2), dp(10), dp(2));
        state.setBackgroundColor(Color.rgb(17,23,31));

        status = text("● متوقف", 11);
        status.setTextColor(Color.LTGRAY);

        lastScan = text("آماده", 9);
        lastScan.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        lastScan.setTextColor(Color.GRAY);
        lastScan.setSingleLine(true);

        state.addView(status, new LinearLayout.LayoutParams(0, dp(30), 1f));
        state.addView(lastScan, new LinearLayout.LayoutParams(0, dp(30), 1.6f));

        LinearLayout.LayoutParams stateLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(34));
        stateLp.topMargin = dp(8);
        root.addView(state, stateLp);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        buttons.setPadding(0, dp(8), 0, dp(10));
        buttons.setClipToPadding(false);

        startBtn = button("شروع");
        stopBtn = button("توقف");
        historyBtn = button("تاریخچه");
        alarmBtn = button("آلارم");

        startBtn.setBackgroundColor(Color.rgb(30,142,94));
        stopBtn.setBackgroundColor(Color.rgb(170,54,62));
        historyBtn.setBackgroundColor(Color.rgb(48,60,74));
        alarmBtn.setBackgroundColor(Color.rgb(72,75,142));

        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        LinearLayout.LayoutParams b3 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        LinearLayout.LayoutParams b4 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        b2.leftMargin = dp(5);
        b3.leftMargin = dp(5);
        b4.leftMargin = dp(5);

        buttons.addView(startBtn, b1);
        buttons.addView(stopBtn, b2);
        buttons.addView(historyBtn, b3);
        buttons.addView(alarmBtn, b4);
        root.addView(buttons);

        if (Build.VERSION.SDK_INT >= 21) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int bottomInset = insets.getSystemWindowInsetBottom();
                int extra = bottomInset + dp(10);
                buttons.setPadding(0, dp(8), 0, extra);
                v.setPadding(dp(6), dp(6), dp(6), dp(6));
                return insets;
            });
        }

        setContentView(root);

        go.setOnClickListener(v -> {
            String u = url.getText().toString().trim();
            if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
            webView.loadUrl(u);
        });

        startBtn.setOnClickListener(v -> startMonitor());
        stopBtn.setOnClickListener(v -> stopMonitor());
        historyBtn.setOnClickListener(v -> showHistory());
        alarmBtn.setOnClickListener(v -> showAlarmSettings());
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowContentAccess(true);
        s.setAllowFileAccess(false);

        if (Build.VERSION.SDK_INT >= 23) s.setOffscreenPreRaster(true);
        if (Build.VERSION.SDK_INT >= 26)
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        String ua = s.getUserAgentString();
        if (ua != null) {
            ua = ua.replace("; wv", "");
            s.setUserAgentString(ua);
        }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);
        cm.flush();

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                CookieManager.getInstance().flush();
                lastScan.setText("صفحه آماده");
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                super.onReceivedError(view, req, err);
                if (req.isForMainFrame()) lastScan.setText("Web error " + err.getErrorCode());
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest req, WebResourceResponse res) {
                super.onReceivedHttpError(view, req, res);
                if (req.isForMainFrame()) lastScan.setText("HTTP " + res.getStatusCode());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                WebView temp = new WebView(MainActivity.this);
                temp.getSettings().setJavaScriptEnabled(true);
                temp.getSettings().setDomStorageEnabled(true);
                temp.setWebViewClient(new WebViewClient() {
                    @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                        Uri uri = request.getUrl();
                        String scheme = uri.getScheme();
                        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                            webView.loadUrl(uri.toString());
                        } else {
                            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                        }
                        try { v.destroy(); } catch (Exception ignored) {}
                        return true;
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(temp);
                resultMsg.sendToTarget();
                return true;
            }

            @Override public void onCloseWindow(WebView window) {
                try { window.destroy(); } catch (Exception ignored) {}
            }
        });
    }

    private void startMonitor() {
        monitoring = true;
        baselineReady = false;
        tracked = null;
        pendingNew = null;
        consecutiveNew = 0;

        getSharedPreferences("astra_state", MODE_PRIVATE)
                .edit().putBoolean("monitor_active", true).apply();

        startMonitorService();
        updateMonitorUi();

        Toast.makeText(this,
                "مانیتورینگ فعال شد؛ اولین اسکن فقط مبناست و آلارم نمی‌دهد",
                Toast.LENGTH_SHORT).show();
    }

    private void startMonitorService() {
        Intent i = new Intent(this, MonitorService.class);
        i.setAction(MonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void stopMonitor() {
        monitoring = false;
        pendingNew = null;
        consecutiveNew = 0;

        getSharedPreferences("astra_state", MODE_PRIVATE)
                .edit().putBoolean("monitor_active", false).apply();

        stopService(new Intent(this, MonitorService.class));
        updateMonitorUi();
    }

    private void updateMonitorUi() {
        if (status == null) return;
        if (monitoring) {
            status.setText("● مانیتور فعال");
            status.setTextColor(Color.rgb(66,220,150));
        } else {
            status.setText("● متوقف");
            status.setTextColor(Color.LTGRAY);
        }
    }

    public static void requestBackgroundScan() {
        MainActivity a = activeActivity.get();
        if (a != null && a.monitoring) a.captureAndScan();
    }

    public static void serviceStopped() {
        MainActivity a = activeActivity.get();
        if (a != null) {
            a.monitoring = false;
            a.runOnUiThread(a::updateMonitorUi);
        }
    }

    private void captureAndScan() {
        if (!monitoring || ocrBusy || webView == null ||
                webView.getWidth() < 100 || webView.getHeight() < 100) return;

        final int w = webView.getWidth();
        final int h = webView.getHeight();

        final int left = (int)(w * 0.55f);
        final int top = (int)(h * 0.12f);
        final int right = w;
        final int bottom = (int)(h * 0.88f);
        final int cropW = right - left;
        final int cropH = bottom - top;

        if (cropW <= 0 || cropH <= 0) return;

        Bitmap raw = Bitmap.createBitmap(cropW, cropH, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(raw);
        canvas.translate(-left, -top);

        try {
            webView.draw(canvas);
        } catch (Exception e) {
            raw.recycle();
            return;
        }

        Bitmap scaled = Bitmap.createScaledBitmap(raw, cropW * 2, cropH * 2, true);
        if (scaled != raw) raw.recycle();

        ocrBusy = true;
        runOcr(scaled);
    }

    private void runOcr(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    SignalDetector.Candidate c = detector.findRightmost(result);
                    processCandidate(c);
                    lastScan.setText(c == null ? "اسکن: بدون سیگنال" : "اسکن: " + c.type);
                })
                .addOnFailureListener(e -> lastScan.setText("OCR error"))
                .addOnCompleteListener(t -> {
                    bitmap.recycle();
                    ocrBusy = false;
                });
    }

    private void processCandidate(SignalDetector.Candidate c) {
        if (!baselineReady) {
            baselineReady = true;
            tracked = c;
            return;
        }

        if (c == null) {
            pendingNew = null;
            consecutiveNew = 0;
            return;
        }

        if (tracked == null) {
            confirmNew(c);
            return;
        }

        boolean differentType = !c.type.equals(tracked.type);
        boolean jumpedRight = c.centerX > tracked.centerX + NEW_JUMP_PX;

        if (!differentType && !jumpedRight) {
            tracked = c;
            pendingNew = null;
            consecutiveNew = 0;
            return;
        }

        if (pendingNew != null &&
                pendingNew.type.equals(c.type) &&
                Math.abs(pendingNew.centerX - c.centerX) < 55) {
            consecutiveNew++;
        } else {
            pendingNew = c;
            consecutiveNew = 1;
        }

        if (consecutiveNew >= 2) {
            announce(c.type);
            tracked = c;
            pendingNew = null;
            consecutiveNew = 0;
        }
    }

    private void confirmNew(SignalDetector.Candidate c) {
        if (pendingNew != null &&
                pendingNew.type.equals(c.type) &&
                Math.abs(pendingNew.centerX - c.centerX) < 55) {
            consecutiveNew++;
        } else {
            pendingNew = c;
            consecutiveNew = 1;
        }

        if (consecutiveNew >= 2) {
            announce(c.type);
            tracked = c;
            pendingNew = null;
            consecutiveNew = 0;
        }
    }

    private void announce(String type) {
        SignalStore.Item item = store.add(type);
        alarm(type, item.time);
        status.setText("● " + type + "  " + item.time);
    }

    private void alarm(String type, String time) {
        SharedPreferences p = getSharedPreferences("astra_alerts", MODE_PRIVATE);

        boolean messageEnabled = p.getBoolean("message_enabled", true);
        boolean vibrateEnabled = p.getBoolean("vibration_enabled", true);
        boolean soundEnabled = p.getBoolean("sound_enabled", true);
        int vibrationMode = p.getInt("vibration_mode", 1);

        String template = p.getString(
                "message_text",
                "سیگنال جدید {type} - ساعت {time}"
        );
        String message = template
                .replace("{type}", type)
                .replace("{time}", time);

        if (soundEnabled) {
            try {
                String saved = p.getString("ringtone_uri", "");
                Uri u = saved == null || saved.isEmpty() ? null : Uri.parse(saved);
                if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

                Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), u);
                if (r != null) r.play();
            } catch (Exception ignored) {}
        }

        if (vibrateEnabled) {
            long[] pattern;
            if (vibrationMode == 0) pattern = new long[]{0, 250};
            else if (vibrationMode == 2) pattern = new long[]{0, 800, 180, 800};
            else pattern = new long[]{0, 250, 120, 250, 120, 500};

            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    VibratorManager vm = (VibratorManager)getSystemService(VIBRATOR_MANAGER_SERVICE);
                    vm.getDefaultVibrator().vibrate(VibrationEffect.createWaveform(pattern, -1));
                } else {
                    Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= 26)
                        v.vibrate(VibrationEffect.createWaveform(pattern, -1));
                    else
                        v.vibrate(pattern, -1);
                }
            } catch (Exception ignored) {}
        }

        if (messageEnabled) {
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(
                    this, 0, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder n = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, SIGNAL_CHANNEL_ID)
                    : new Notification.Builder(this);

            n.setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle("ASTRA " + type)
                    .setContentText(message)
                    .setStyle(new Notification.BigTextStyle().bigText(message))
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .setPriority(Notification.PRIORITY_MAX);

            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .notify((int)(System.currentTimeMillis() & 0x7fffffff), n.build());

            if (hasWindowFocus()) {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showAlarmSettings() {
        SharedPreferences p = getSharedPreferences("astra_alerts", MODE_PRIVATE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(4));

        CheckBox message = new CheckBox(this);
        message.setText("پیام / نوتیفیکیشن");
        message.setTextColor(Color.WHITE);
        message.setChecked(p.getBoolean("message_enabled", true));

        CheckBox vibration = new CheckBox(this);
        vibration.setText("ویبره");
        vibration.setTextColor(Color.WHITE);
        vibration.setChecked(p.getBoolean("vibration_enabled", true));

        CheckBox sound = new CheckBox(this);
        sound.setText("زنگ");
        sound.setTextColor(Color.WHITE);
        sound.setChecked(p.getBoolean("sound_enabled", true));

        TextView msgLabel = text("متن پیام  (از {type} و {time} می‌توانی استفاده کنی)", 12);
        msgLabel.setPadding(0, dp(10), 0, dp(4));

        EditText msg = new EditText(this);
        msg.setTextColor(Color.WHITE);
        msg.setHintTextColor(Color.GRAY);
        msg.setBackgroundColor(Color.rgb(26,34,44));
        msg.setPadding(dp(10), dp(8), dp(10), dp(8));
        msg.setText(p.getString("message_text", "سیگنال جدید {type} - ساعت {time}"));

        TextView vibLabel = text("الگوی ویبره", 12);
        vibLabel.setPadding(0, dp(10), 0, dp(4));

        Spinner vibrationMode = new Spinner(this);
        String[] modes = new String[]{"کوتاه", "معمولی", "قوی"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, modes);
        vibrationMode.setAdapter(adapter);
        vibrationMode.setSelection(p.getInt("vibration_mode", 1));

        Button ringtone = button("انتخاب صدای زنگ");
        ringtone.setBackgroundColor(Color.rgb(55,66,80));
        ringtone.setOnClickListener(v -> openRingtonePicker());

        box.addView(message);
        box.addView(vibration);
        box.addView(sound);
        box.addView(msgLabel);
        box.addView(msg, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));
        box.addView(vibLabel);
        box.addView(vibrationMode, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        LinearLayout.LayoutParams ringLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        ringLp.topMargin = dp(10);
        box.addView(ringtone, ringLp);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("مدیریت آلارم")
                .setView(scroll)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ذخیره", (d, w) -> {
                    p.edit()
                            .putBoolean("message_enabled", message.isChecked())
                            .putBoolean("vibration_enabled", vibration.isChecked())
                            .putBoolean("sound_enabled", sound.isChecked())
                            .putString("message_text", msg.getText().toString().trim())
                            .putInt("vibration_mode", vibrationMode.getSelectedItemPosition())
                            .apply();
                    Toast.makeText(this, "تنظیمات آلارم ذخیره شد", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void openRingtonePicker() {
        SharedPreferences p = getSharedPreferences("astra_alerts", MODE_PRIVATE);
        Intent i = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,
                RingtoneManager.TYPE_ALARM | RingtoneManager.TYPE_NOTIFICATION);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);

        String saved = p.getString("ringtone_uri", "");
        Uri existing = saved == null || saved.isEmpty()
                ? RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                : Uri.parse(saved);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing);

        try {
            startActivityForResult(i, REQ_RINGTONE);
        } catch (Exception e) {
            Toast.makeText(this, "انتخاب صدای زنگ روی این گوشی در دسترس نیست",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_RINGTONE && resultCode == RESULT_OK && data != null) {
            Uri picked = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (picked != null) {
                getSharedPreferences("astra_alerts", MODE_PRIVATE)
                        .edit().putString("ringtone_uri", picked.toString()).apply();
                Toast.makeText(this, "صدای زنگ انتخاب شد", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showHistory() {
        List<SignalStore.Item> items = store.getAll();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(8));

        if (items.isEmpty()) {
            box.addView(text("هنوز سیگنالی ثبت نشده", 15));
        } else {
            for (int i=0; i<items.size(); i++) {
                SignalStore.Item s = items.get(i);
                TextView t = text((i+1) + "   " + s.type + "   " + s.date + "   " + s.time, 15);
                t.setPadding(0, dp(10), 0, dp(10));
                t.setTextColor(s.type.equals("BUY")
                        ? Color.rgb(92,230,174)
                        : Color.rgb(255,125,133));
                box.addView(t);
            }
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("تاریخچه سیگنال‌ها")
                .setView(scroll)
                .setNegativeButton("پاک کردن", (d,w) -> {
                    store.clear();
                    Toast.makeText(this, "تاریخچه پاک شد", Toast.LENGTH_SHORT).show();
                })
                .setPositiveButton("بستن", null)
                .show();
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm =
                    (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

            NotificationChannel signal = new NotificationChannel(
                    SIGNAL_CHANNEL_ID,
                    "Astra Signal Alerts",
                    NotificationManager.IMPORTANCE_HIGH);
            signal.setDescription("BUY/SELL signal notifications");
            signal.setSound(null, null);
            signal.enableVibration(false);
            nm.createNotificationChannel(signal);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        activeActivity = new WeakReference<>(this);
        monitoring = getSharedPreferences("astra_state", MODE_PRIVATE)
                .getBoolean("monitor_active", false);
        updateMonitorUi();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        MainActivity a = activeActivity.get();
        if (a == this) activeActivity = new WeakReference<>(null);

        if (recognizer != null) recognizer.close();
        if (webView != null) {
            try { webView.destroy(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
