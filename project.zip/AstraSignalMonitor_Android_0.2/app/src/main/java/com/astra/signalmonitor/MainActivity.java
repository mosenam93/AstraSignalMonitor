package com.astra.signalmonitor;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.List;

public class MainActivity extends Activity {
    private static final String CHANNEL_ID = "astra_signal_alerts";
    private static final long SCAN_MS = 1500;
    private static final int NEW_JUMP_PX = 80; // OCR image is 2x scaled
    private static final long MISS_GRACE_MS = 15000;

    private WebView webView;
    private TextView status, lastScan;
    private Button startBtn, stopBtn, historyBtn;
    private boolean monitoring = false;
    private boolean ocrBusy = false;
    private boolean baselineReady = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextRecognizer recognizer;
    private final SignalDetector detector = new SignalDetector();
    private SignalStore store;

    private SignalDetector.Candidate tracked = null;
    private long trackedLastSeen = 0L;
    private int consecutiveNew = 0;
    private SignalDetector.Candidate pendingNew = null;

    private final Runnable scanLoop = new Runnable() {
        @Override public void run() {
            if (monitoring) captureAndScan();
            handler.postDelayed(this, SCAN_MS);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11,15,20));
        store = new SignalStore(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        createNotificationChannel();
        requestNotificationPermission();
        buildUi();
        configureWebView();
        webView.loadUrl("https://www.tradingview.com/chart/");
        handler.post(scanLoop);
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, int sp) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(13); b.setAllCaps(false); return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11,15,20));
        root.setPadding(dp(8), dp(8), dp(8), dp(8));

        LinearLayout urlRow = new LinearLayout(this); urlRow.setOrientation(LinearLayout.HORIZONTAL);
        final EditText url = new EditText(this);
        url.setSingleLine(true); url.setText("https://www.tradingview.com/chart/"); url.setTextColor(Color.WHITE);
        url.setHintTextColor(Color.GRAY); url.setTextSize(12); url.setBackgroundColor(Color.rgb(18,25,34));
        Button go = button("GO");
        urlRow.addView(url, new LinearLayout.LayoutParams(0, dp(48), 1f));
        urlRow.addView(go, new LinearLayout.LayoutParams(dp(72), dp(48)));
        root.addView(urlRow);

        webView = new WebView(this);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, 0, 1f); wp.topMargin = dp(6);
        root.addView(webView, wp);

        LinearLayout state = new LinearLayout(this); state.setOrientation(LinearLayout.HORIZONTAL); state.setGravity(Gravity.CENTER_VERTICAL);
        status = text("● متوقف", 14); status.setTextColor(Color.LTGRAY);
        lastScan = text("", 11); lastScan.setTextColor(Color.GRAY); lastScan.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        state.addView(status, new LinearLayout.LayoutParams(0, dp(38), 1f));
        state.addView(lastScan, new LinearLayout.LayoutParams(0, dp(38), 1f));
        root.addView(state);

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        startBtn = button("شروع مانیتور"); stopBtn = button("توقف"); historyBtn = button("تاریخچه");
        buttons.addView(startBtn, new LinearLayout.LayoutParams(0, dp(52), 1f));
        buttons.addView(stopBtn, new LinearLayout.LayoutParams(0, dp(52), 1f));
        buttons.addView(historyBtn, new LinearLayout.LayoutParams(0, dp(52), 1f));
        root.addView(buttons);

        setContentView(root);

        go.setOnClickListener(v -> {
            String u = url.getText().toString().trim();
            if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
            webView.loadUrl(u);
        });
        startBtn.setOnClickListener(v -> startMonitor());
        stopBtn.setOnClickListener(v -> stopMonitor());
        historyBtn.setOnClickListener(v -> showHistory());
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        webView.setWebChromeClient(new WebChromeClient());
    }

    private void startMonitor() {
        monitoring = true;
        baselineReady = false;
        tracked = null;
        trackedLastSeen = 0;
        pendingNew = null;
        consecutiveNew = 0;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        status.setText("● در حال مانیتور"); status.setTextColor(Color.rgb(66,220,150));
        Toast.makeText(this, "اولین اسکن فقط Baseline است و آلارم نمی‌دهد", Toast.LENGTH_SHORT).show();
    }

    private void stopMonitor() {
        monitoring = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        status.setText("● متوقف"); status.setTextColor(Color.LTGRAY);
        pendingNew = null; consecutiveNew = 0;
    }

    private void captureAndScan() {
        if (ocrBusy || webView.getWidth() < 100 || webView.getHeight() < 100) return;
        int[] loc = new int[2]; webView.getLocationInWindow(loc);
        int w = webView.getWidth(), h = webView.getHeight();

        // Right-most 45% of chart, excluding top/bottom 12% UI bars.
        int left = loc[0] + (int)(w * 0.55f);
        int top = loc[1] + (int)(h * 0.12f);
        int right = loc[0] + w;
        int bottom = loc[1] + (int)(h * 0.88f);
        Rect src = new Rect(left, top, right, bottom);
        if (src.width() <= 0 || src.height() <= 0) return;
        Bitmap raw = Bitmap.createBitmap(src.width(), src.height(), Bitmap.Config.ARGB_8888);
        ocrBusy = true;
        PixelCopy.request(getWindow(), src, raw, result -> {
            if (result != PixelCopy.SUCCESS) { ocrBusy = false; return; }
            Bitmap scaled = Bitmap.createScaledBitmap(raw, raw.getWidth()*2, raw.getHeight()*2, true);
            if (scaled != raw) raw.recycle();
            runOcr(scaled);
        }, handler);
    }

    private void runOcr(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    SignalDetector.Candidate c = detector.findRightmost(result);
                    processCandidate(c);
                    lastScan.setText(c == null ? "اسکن: بدون سیگنال" : "اسکن: " + c.type);
                })
                .addOnFailureListener(e -> lastScan.setText("OCR error"))
                .addOnCompleteListener(t -> { bitmap.recycle(); ocrBusy = false; });
    }

    private void processCandidate(SignalDetector.Candidate c) {
        long now = System.currentTimeMillis();

        // First successful scan is baseline. Existing badge must never alert.
        if (!baselineReady) {
            baselineReady = true;
            tracked = c;
            trackedLastSeen = c == null ? 0 : now;
            return;
        }

        if (c == null) {
            pendingNew = null; consecutiveNew = 0;
            // Keep tracked signal during OCR misses so it cannot re-alert.
            return;
        }

        if (tracked == null) {
            confirmNew(c);
            return;
        }

        boolean differentType = !c.type.equals(tracked.type);
        boolean jumpedRight = c.centerX > tracked.centerX + NEW_JUMP_PX;

        // Same visible badge normally drifts left as new candles arrive; that is not a new signal.
        if (!differentType && !jumpedRight) {
            tracked = c;
            trackedLastSeen = now;
            pendingNew = null; consecutiveNew = 0;
            return;
        }

        // Require 2 consecutive OCR frames for a new signal to reduce false alarms.
        if (pendingNew != null && pendingNew.type.equals(c.type) && Math.abs(pendingNew.centerX - c.centerX) < 55) {
            consecutiveNew++;
        } else {
            pendingNew = c;
            consecutiveNew = 1;
        }

        if (consecutiveNew >= 2) {
            announce(c.type);
            tracked = c;
            trackedLastSeen = now;
            pendingNew = null; consecutiveNew = 0;
        }
    }

    private void confirmNew(SignalDetector.Candidate c) {
        if (pendingNew != null && pendingNew.type.equals(c.type) && Math.abs(pendingNew.centerX - c.centerX) < 55) consecutiveNew++;
        else { pendingNew = c; consecutiveNew = 1; }
        if (consecutiveNew >= 2) {
            announce(c.type); tracked = c; trackedLastSeen = System.currentTimeMillis(); pendingNew = null; consecutiveNew = 0;
        }
    }

    private void announce(String type) {
        SignalStore.Item item = store.add(type);
        alarm(type, item.time);
        status.setText("● " + type + "  " + item.time);
    }

    private void alarm(String type, String time) {
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, u);
            if (r != null) r.play();
        } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= 31) {
            VibratorManager vm = (VibratorManager)getSystemService(VIBRATOR_MANAGER_SERVICE);
            vm.getDefaultVibrator().vibrate(VibrationEffect.createWaveform(new long[]{0,250,120,250,120,500}, -1));
        } else {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            v.vibrate(VibrationEffect.createWaveform(new long[]{0,250,120,250,120,500}, -1));
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder n = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        n.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("ASTRA " + type)
                .setContentText("سیگنال جدید - ساعت " + time)
                .setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_MAX);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis() & 0x7fffffff), n.build());
        Toast.makeText(this, type + "  " + time, Toast.LENGTH_LONG).show();
    }

    private void showHistory() {
        List<SignalStore.Item> items = store.getAll();
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(8),dp(18),dp(8));
        if (items.isEmpty()) box.addView(text("هنوز سیگنالی ثبت نشده", 15));
        else {
            for (int i=0;i<items.size();i++) {
                SignalStore.Item s = items.get(i);
                TextView t = text((i+1) + "   " + s.type + "   " + s.date + "   " + s.time, 15);
                t.setPadding(0,dp(10),0,dp(10));
                t.setTextColor(s.type.equals("BUY") ? Color.rgb(92,230,174) : Color.rgb(255,125,133));
                box.addView(t);
            }
        }
        ScrollView scroll = new ScrollView(this); scroll.addView(box);
        new AlertDialog.Builder(this).setTitle("تاریخچه سیگنال‌ها").setView(scroll)
                .setNegativeButton("پاک کردن", (d,w) -> { store.clear(); Toast.makeText(this,"تاریخچه پاک شد",Toast.LENGTH_SHORT).show(); })
                .setPositiveButton("بستن", null).show();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Astra Signals", NotificationManager.IMPORTANCE_HIGH);
            c.enableVibration(true); c.setDescription("BUY/SELL alerts detected on the visible chart");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        monitoring = false; handler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.close();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
