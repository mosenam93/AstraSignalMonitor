package com.astra.signalmonitor;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SignalStore {
    private static final String PREF = "astra_signals";
    private static final String KEY = "history";
    private final SharedPreferences prefs;

    public static class Item {
        public final String type;
        public final String date;
        public final String time;
        public final long timestamp;

        public Item(String type, String date, String time, long timestamp) {
            this.type = type; this.date = date; this.time = time; this.timestamp = timestamp;
        }
    }

    public SignalStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public synchronized Item add(String type) {
        long now = System.currentTimeMillis();
        String date = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(new Date(now));
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(now));
        Item item = new Item(type, date, time, now);
        List<Item> all = getAll();
        all.add(0, item);
        while (all.size() > 500) all.remove(all.size() - 1);
        save(all);
        return item;
    }

    public synchronized List<Item> getAll() {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i=0;i<a.length();i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Item(o.getString("type"), o.getString("date"), o.getString("time"), o.getLong("timestamp")));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public synchronized void clear() {
        prefs.edit().remove(KEY).apply();
    }

    private void save(List<Item> items) {
        JSONArray a = new JSONArray();
        try {
            for (Item i : items) {
                JSONObject o = new JSONObject();
                o.put("type", i.type);
                o.put("date", i.date);
                o.put("time", i.time);
                o.put("timestamp", i.timestamp);
                a.put(o);
            }
        } catch (Exception ignored) {}
        prefs.edit().putString(KEY, a.toString()).apply();
    }
}
