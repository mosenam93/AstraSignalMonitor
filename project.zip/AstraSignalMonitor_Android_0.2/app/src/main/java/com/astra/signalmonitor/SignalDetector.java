package com.astra.signalmonitor;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class SignalDetector {
    public static class Candidate {
        public final String type;
        public final int centerX;
        public final int centerY;
        public final int right;
        public Candidate(String type, int centerX, int centerY, int right) {
            this.type = type; this.centerX = centerX; this.centerY = centerY; this.right = right;
        }
    }

    public Candidate findRightmost(Text result) {
        List<Candidate> list = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                addIfSignal(list, line.getText(), line.getBoundingBox());
                for (Text.Element e : line.getElements()) addIfSignal(list, e.getText(), e.getBoundingBox());
            }
        }
        if (list.isEmpty()) return null;
        list.sort(Comparator.comparingInt((Candidate c) -> c.right).reversed());
        return list.get(0);
    }

    private void addIfSignal(List<Candidate> out, String raw, Rect box) {
        if (raw == null || box == null) return;
        String s = raw.toUpperCase(Locale.US).replaceAll("[^A-Z]", "").trim();
        String type = null;
        if (s.equals("BUY") || s.endsWith("BUY")) type = "BUY";
        else if (s.equals("SELL") || s.endsWith("SELL")) type = "SELL";
        if (type != null) out.add(new Candidate(type, box.centerX(), box.centerY(), box.right));
    }
}
