package com.astra.signalmonitor;

import android.app.*;
import android.content.*;
import android.os.*;

public class MonitorService extends Service {
    public static final String ACTION_START = "com.astra.signalmonitor.START_MONITOR";
    public static final String ACTION_STOP = "com.astra.signalmonitor.STOP_MONITOR";

    private static final String CHANNEL_ID = "astra_monitor_service";
    private static final int NOTIFICATION_ID = 7401;
    private static final long SCAN_MS = 1500L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private boolean started = false;

    private final Runnable scanner = new Runnable() {
        @Override public void run() {
            if (started) {
                MainActivity.requestBackgroundScan();
                handler.postDelayed(this, SCAN_MS);
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopMonitoring();
            return START_NOT_STICKY;
        }

        boolean shouldRun = getSharedPreferences("astra_state", MODE_PRIVATE)
                .getBoolean("monitor_active", false);

        if (!shouldRun) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!started) {
            started = true;
            startForeground(NOTIFICATION_ID, buildNotification());
            acquireWakeLock();
            handler.removeCallbacks(scanner);
            handler.post(scanner);
        }

        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, MonitorService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 11, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return b.setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("Astra Monitor فعال است")
                .setContentText("اسکن سیگنال‌ها در پس‌زمینه ادامه دارد")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_media_pause, "توقف", stopPi)
                .setPriority(Notification.PRIORITY_LOW)
                .build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "AstraSignalMonitor:BackgroundScan");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Exception ignored) {}
    }

    private void stopMonitoring() {
        started = false;
        handler.removeCallbacks(scanner);

        getSharedPreferences("astra_state", MODE_PRIVATE)
                .edit().putBoolean("monitor_active", false).apply();

        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }

        MainActivity.serviceStopped();
        stopForeground(true);
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID,
                    "Astra Background Monitor",
                    NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Persistent notification while Astra scans in the background");
            c.setSound(null, null);
            c.enableVibration(false);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        started = false;
        handler.removeCallbacks(scanner);
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
