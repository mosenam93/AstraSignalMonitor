# WiFi Guard 2.3

Android manager for Huawei HG-series ONT/router.

## v2.3
- Adds a manual **Modem / لغو مودم** control to the Rename dialog.
- A manually marked modem gets the blue **Modem** badge, is excluded from the online-client count, is sorted to the bottom, and has no remaining-quota control.
- Device list ordering is now: **Online clients first -> Offline/known clients -> Modem last**.
- The header counter now counts online client devices only and excludes the modem.
- Usage sampling now asks Huawei to rebuild the User Device Information data before reading RX/TX rates, improving the local remaining-quota estimate on HG8546M builds that return stale zero rates.
- Manual Refresh also forces the fresh traffic sample.
- Keeps the fixed signing key used by the 2.x line.

### Usage accounting note
HG8546M does not expose confirmed persistent per-client cumulative byte totals on the known pages. WiFi Guard therefore estimates usage from the RX/TX rate samples while the app is running. Traffic that happened while the app was not sampling cannot be reconstructed later.
