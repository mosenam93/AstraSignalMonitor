# WiFi Guard 2.4

Android manager for Huawei HG-series ONT/router.

## v2.4
- Adds an in-app **traffic diagnostics test** inside each device quota dialog.
- Shows the exact raw RX/TX values returned by Huawei, the parsed B/s rate, and the raw PTVDF argument count/positions.
- Accepts Huawei rate fields that include units (KB/s, MB/s, Kbps, Mbps) instead of only plain numbers.
- Scans the PTVDF tail for compatible traffic fields when args 10/11 are not usable.
- Manual Refresh and the background monitor keep updating the diagnostic sample and quota estimate.
- If the modem really returns no per-client traffic field (or only zeros), the UI now says so explicitly instead of silently showing a frozen quota.
- Keeps the manual Modem selection, list ordering, and fixed signing key from the 2.x line.

### Usage accounting note
HG8546M firmware variants differ. Some expose live per-client RX/TX rates; others do not expose persistent per-client byte counters. WiFi Guard can estimate usage only when the router returns a usable per-client traffic rate while the app is sampling.

