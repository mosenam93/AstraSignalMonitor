# WiFi Guard 2.1

Android manager for Huawei HG-series ONT/router.

## v2.1
- Replaces the device icon above Rename with a compact live-traffic / remaining-quota panel.
- Tap the panel to set a monthly quota in GB or reset the current month's local usage counter.
- Polls the Huawei user-device feed every 5 seconds while the app is running and displays per-device live traffic when the firmware exposes RX/TX rate fields.
- Estimates monthly usage by integrating those sampled per-device rates and stores usage per MAC and calendar month.
- Keeps the stable signing key introduced in v2.0 so future builds install over v2.0+ without deleting app data.

### Accuracy note
The HG8546M firmware tested so far does not expose a reliable cumulative monthly byte counter per client through the same web endpoint. The app's per-device monthly figure is therefore an estimate accumulated while WiFi Guard monitoring is active. If the firmware does not expose per-device RX/TX rate fields, live rate remains 0 and the estimate cannot advance until a supported counter/rate endpoint is found.
