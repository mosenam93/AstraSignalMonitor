# WiFi Guard 1.2

Android app for Huawei HG/EG ONT web interfaces.

## Features
- Login to the router at `192.168.100.1` (configurable)
- Multi-endpoint connected-device discovery:
  - `/html/bbsp/common/GetLanUserDevInfo.asp` (GET/POST, `USERDevice` / `USERDeviceNew`)
  - `/html/bbsp/userdevinfo/getuserdevinfo.asp` (GET/POST, `stUserDevInfoPTVDF`)
  - `/GetLanUserDevInfo.asp` fallback
- Displays IP, MAC, interface and connection status
- Local custom names (Rename)
- Block/unblock through Huawei MAC Filter / WLAN MAC Filter when exposed by firmware
- Dark card UI matching the WiFi Guard HTML concept

The router admin password is not persisted by the app.

## Build
Use Android SDK 35, Java 17 and Gradle 8.9.

```bash
gradle -p WiFiGuard :app:assembleDebug
```
