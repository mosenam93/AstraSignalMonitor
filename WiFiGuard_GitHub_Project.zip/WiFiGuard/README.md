# WiFi Guard 1.6

Android app for Huawei HG-series ONT/router management.

Changes in 1.6:
- Blocking now prefers the verified global MAC Filter page used by HG8546M (`macfilter.asp`) instead of the WLAN-only filter page.
- Blacklist mode is enabled with the HG8546M-compatible `MacFilterRight` / `MacFilterPolicy` fields and verified after the write.
- User Device Information is refreshed before reading when the firmware supports the Huawei rebuild-state flow.
- Connection duration is rendered as readable hours/minutes instead of the ambiguous raw router value.
- The router/modem badge is shown as blue `Modem` when the device matches the router address/model.
- Live RX/TX traffic rate is shown when the firmware exposes those fields. Cumulative per-client byte usage is not exposed by every HG8546M firmware.
