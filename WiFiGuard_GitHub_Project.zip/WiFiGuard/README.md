# WiFi Guard

Android app for Huawei HG-series ONT/router panels such as the web UI at `192.168.100.1`.

Features:
- Login directly to the Huawei modem/router panel over local Wi‑Fi
- Show connected devices with IP/MAC/status/interface
- Save a custom display name for each device inside the app
- Block/unblock devices through the modem's MAC Filter blacklist
- Cleartext HTTP enabled because many Huawei ONTs expose the local admin panel over HTTP only

## Build APK with GitHub Actions
1. Create a GitHub repository.
2. Upload **the contents of this folder** to the repository root, including the hidden `.github` folder.
3. Commit to the `main` branch.
4. Open **Actions → Build WiFi Guard APK**.
5. Open the latest successful run.
6. Download the artifact named **WiFiGuard-APK**.
7. Inside it is `WiFiGuard-v1.0-debug.apk`.

You can also run the workflow manually with **Run workflow**.

## Router compatibility
The current implementation targets Huawei firmware using these pages/endpoints:
- `/asp/GetRandCount.asp`
- `/login.cgi`
- `/html/bbsp/userdevinfo/getuserdevinfo.asp`
- `/html/bbsp/macfilter/macfilter.asp`
- `/html/bbsp/macfilter/add.cgi`
- `/html/bbsp/macfilter/del.cgi`
- `/html/bbsp/macfilter/set.cgi`

Some Huawei ISP firmware variants may use different paths or permissions.
