# WiFi Guard 2.2

Android manager for Huawei HG-series ONT/router.

## v2.2
- Replaces the two-line live-traffic/quota panel with one compact **remaining quota** badge.
- The remaining-quota badge is the same size as the Rename button and sits in the same left action column.
- Manual **Refresh** also refreshes the per-device traffic snapshot before updating the local monthly usage estimate.
- Modem detection is more robust: the configured gateway IP (and the .1 gateway in the same subnet) always gets a blue **Modem** badge even if Huawei reports that row as Offline.
- Keeps the fixed signing key introduced in v2.0, so it remains installable over v2.0+ builds signed with the same key.

### Usage accounting note
HG8546M firmware does not reliably expose a cumulative monthly byte counter per client. WiFi Guard therefore keeps a local estimate from the per-device RX/TX rate samples that the firmware exposes. Manual Refresh now samples that feed too.
