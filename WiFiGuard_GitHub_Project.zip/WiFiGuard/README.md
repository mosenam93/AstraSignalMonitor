# WiFi Guard v1.7

Changes in v1.7:
- Fix HG8546M blocking: Wi-Fi clients are now written to the WLAN MAC filter first, with automatic blacklist activation and a generic MAC-filter fallback.
- Fresh security token is read before each filter write and the rule is verified after creation.
- Blocked state is read from both WLAN and generic MAC-filter lists.
- Keeps the compact device cards, Modem badge, and corrected connection-duration formatting from v1.6.
- Per-device cumulative traffic volume is not exposed by the HG8546M device-list endpoint; the app only shows RX/TX rate when the firmware supplies it.

# WiFi Guard 1.6

Android app for Huawei HG-series ONT/router management.

Changes in 1.6:
- Blocking now prefers the verified global MAC Filter page used by HG8546M (`macfilter.asp`) instead of the WLAN-only filter page.
- Blacklist mode is enabled with the HG8546M-compatible `MacFilterRight` / `MacFilterPolicy` fields and verified after the write.
- User Device Information is refreshed before reading when the firmware supports the Huawei rebuild-state flow.
- Connection duration is rendered as readable hours/minutes instead of the ambiguous raw router value.
- The router/modem badge is shown as blue `Modem` when the device matches the router address/model.
- Live RX/TX traffic rate is shown when the firmware exposes those fields. Cumulative per-client byte usage is not exposed by every HG8546M firmware.


## v1.8
- Refresh retries transient empty HG8546M snapshots and preserves the last good device list instead of flashing 0.
- Offline devices now show a red Offline badge; online stays green and modem stays blue.
