# WiFi Guard

Android app for Huawei HG-series ONT/router web interfaces (default 192.168.100.1).

Features:
- Login to the local Huawei router web UI.
- Read connected devices from `getuserdevinfo.asp`.
- Show device IP/MAC/interface/status.
- Local custom alias per MAC address.
- Block/unblock using the Huawei MAC Filter blacklist CGI pages.
- Refresh device list.

Important:
- The router admin password is not saved by the app.
- The custom device name is stored only in the app.
- Cleartext HTTP is enabled because these Huawei ONTs commonly expose their local admin UI via HTTP.
- Firmware variants may use different page paths/field names; this implementation targets the Huawei HG web UI family that exposes `html/bbsp/userdevinfo` and automatically tries both `html/bbsp/wlanmacfilter` and `html/bbsp/macfilter`.


v1.1 fixes:
- Device list no longer fails when MAC Filter parsing fails.
- Tries Huawei WLAN MAC Filter first, then LAN MAC Filter fallback.
- More flexible Huawei CSRF/ONT token parser.
- Supports WLAN blacklist fields used by HG/EG firmware variants.
