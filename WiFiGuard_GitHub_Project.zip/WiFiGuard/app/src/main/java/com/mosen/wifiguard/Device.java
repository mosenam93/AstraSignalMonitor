package com.mosen.wifiguard;

public class Device {
    public String routerName;
    public String ip;
    public String mac;
    public String status;
    public String iface;
    public String connectedTime;
    public String rxRate;
    public String txRate;
    public boolean blocked;

    // WiFi Guard local usage accounting. Huawei HG8546M exposes a live
    // per-client traffic rate on some firmware builds, but not a reliable
    // monthly total. The app therefore integrates the sampled rate while its
    // monitor is active and persists the estimate per MAC/current month.
    public long liveRateBytesPerSecond;
    public long usedBytesThisMonth;
    public long quotaBytes;

    public Device(String routerName, String ip, String mac, String status,
                  String iface, String connectedTime) {
        this(routerName, ip, mac, status, iface, connectedTime, "", "");
    }

    public Device(String routerName, String ip, String mac, String status,
                  String iface, String connectedTime, String rxRate, String txRate) {
        this.routerName = routerName;
        this.ip = ip;
        this.mac = mac;
        this.status = status;
        this.iface = iface;
        this.connectedTime = connectedTime;
        this.rxRate = rxRate;
        this.txRate = txRate;
    }
}
