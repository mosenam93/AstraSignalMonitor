package com.mosen.wifiguard;

public class Device {
    public String routerName;
    public String ip;
    public String mac;
    public String status;
    public String iface;
    public String connectedTime;
    public boolean blocked;

    public Device(String routerName, String ip, String mac, String status,
                  String iface, String connectedTime) {
        this.routerName = routerName;
        this.ip = ip;
        this.mac = mac;
        this.status = status;
        this.iface = iface;
        this.connectedTime = connectedTime;
    }
}
