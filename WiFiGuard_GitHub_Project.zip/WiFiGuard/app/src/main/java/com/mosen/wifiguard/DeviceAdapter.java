package com.mosen.wifiguard;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DeviceAdapter extends BaseAdapter {
    public interface Listener {
        void onRename(Device d);
        void onToggleBlock(Device d);
    }

    private final Context context;
    private final SharedPreferences prefs;
    private final Listener listener;
    private final List<Device> items = new ArrayList<>();

    public DeviceAdapter(Context context, SharedPreferences prefs, Listener listener) {
        this.context = context;
        this.prefs = prefs;
        this.listener = listener;
    }

    public void setItems(List<Device> devices) {
        items.clear();
        items.addAll(devices);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Device getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    private int dp(int x) { return (int)(x * context.getResources().getDisplayMetrics().density + .5f); }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Device d = getItem(position);
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(dp(12), dp(6), dp(12), dp(6));
        card.setLayoutParams(cp);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0xFFE4E7EC);
        card.setBackground(bg);

        String alias = prefs.getString("alias_" + d.mac, "");
        TextView name = new TextView(context);
        name.setText(alias.isEmpty() ? safe(d.routerName, "دستگاه ناشناس") : alias);
        name.setTextSize(18);
        name.setTextColor(0xFF101828);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setGravity(Gravity.RIGHT);
        card.addView(name);

        TextView meta = new TextView(context);
        String rn = alias.isEmpty() ? "" : "نام مودم: " + safe(d.routerName, "-") + "\n";
        meta.setText(rn + "IP: " + safe(d.ip, "-") + "\nMAC: " + safe(d.mac, "-") + "\nرابط: " + safe(d.iface, "-") + "   وضعیت: " + safe(d.status, "-"));
        meta.setTextSize(13);
        meta.setTextColor(0xFF667085);
        meta.setGravity(Gravity.RIGHT);
        meta.setPadding(0, dp(8), 0, dp(10));
        card.addView(meta);

        LinearLayout actions = new LinearLayout(context);
        actions.setGravity(Gravity.RIGHT);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button rename = new Button(context);
        rename.setText("ویرایش نام");
        rename.setOnClickListener(v -> listener.onRename(d));
        actions.addView(rename);

        Button block = new Button(context);
        block.setText(d.blocked ? "رفع بلاک" : "بلاک");
        block.setTextColor(d.blocked ? 0xFF067647 : 0xFFB42318);
        block.setOnClickListener(v -> listener.onToggleBlock(d));
        actions.addView(block);
        card.addView(actions);
        return card;
    }

    private static String safe(String s, String def) { return s == null || s.trim().isEmpty() ? def : s; }
}
