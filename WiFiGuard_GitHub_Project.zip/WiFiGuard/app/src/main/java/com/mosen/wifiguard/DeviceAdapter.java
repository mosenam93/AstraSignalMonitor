package com.mosen.wifiguard;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class DeviceAdapter extends BaseAdapter {
    public interface Listener {
        void onRename(Device d);
        void onToggleBlock(Device d);
        void onUsage(Device d);
    }

    private static final int CARD = 0xFF111C2D;
    private static final int BORDER = 0xFF24344F;
    private static final int TEXT = 0xFFF3F7FC;
    private static final int MUTED = 0xFF94A6BE;

    private final Context context;
    private final SharedPreferences prefs;
    private final Listener listener;
    private final List<Device> items = new ArrayList<>();

    public DeviceAdapter(Context context, SharedPreferences prefs, Listener listener) {
        this.context = context;
        this.prefs = prefs;
        this.listener = listener;
    }

    public void setItems(List<Device> devices) {
        items.clear();
        if (devices != null) items.addAll(devices);
        sortItems();
        notifyDataSetChanged();
    }

    public void resortAndRefresh() {
        sortItems();
        notifyDataSetChanged();
    }

    public int getOnlineClientCount() {
        int count = 0;
        for (Device d : items) {
            if (!isModem(d) && isOnline(d)) count++;
        }
        return count;
    }

    private void sortItems() {
        // Online clients first, then offline/known clients, and the manually
        // selected modem row always at the bottom. Collections.sort is stable,
        // so devices keep the router's original order inside each group.
        Collections.sort(items, (a, b) -> Integer.compare(sortRank(a), sortRank(b)));
    }

    private int sortRank(Device d) {
        if (isModem(d)) return 2;
        return isOnline(d) ? 0 : 1;
    }

    public void mergeTraffic(List<Device> snapshot) {
        if (snapshot == null || snapshot.isEmpty()) return;
        for (Device current : items) {
            String cm = safe(current.mac, "");
            if (cm.isEmpty()) continue;
            for (Device fresh : snapshot) {
                if (!cm.equalsIgnoreCase(safe(fresh.mac, ""))) continue;
                current.rxRate = fresh.rxRate;
                current.txRate = fresh.txRate;
                current.liveRateBytesPerSecond = fresh.liveRateBytesPerSecond;
                current.usedBytesThisMonth = fresh.usedBytesThisMonth;
                current.quotaBytes = fresh.quotaBytes;
                current.trafficDiagnostic = fresh.trafficDiagnostic;
                current.trafficSampleTimeMs = fresh.trafficSampleTimeMs;
                if (fresh.status != null && !fresh.status.trim().isEmpty()) current.status = fresh.status;
                if (fresh.connectedTime != null && !fresh.connectedTime.trim().isEmpty()) current.connectedTime = fresh.connectedTime;
                break;
            }
        }
        sortItems();
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Device getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    private int dp(int x) { return (int)(x * context.getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private Button button(String text, int color, int textColor) {
        Button b = new Button(context);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setBackground(bg(color, 11, color));
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Device d = getItem(position);

        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(dp(12), dp(4), dp(12), dp(4));
        card.setLayoutParams(cp);
        card.setBackground(bg(CARD, 16, BORDER));

        LinearLayout top = new LinearLayout(context);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout nameBox = new LinearLayout(context);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        nameBox.setGravity(Gravity.RIGHT);
        nameBox.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        String alias = prefs.getString("alias_" + safe(d.mac, ""), "");
        String shown = alias.isEmpty() ? safe(d.routerName, "دستگاه ناشناس") : alias;

        TextView name = new TextView(context);
        name.setText(d.blocked ? "🚫 " + shown : shown);
        name.setTextSize(16);
        name.setTextColor(TEXT);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setGravity(Gravity.RIGHT);
        name.setSingleLine(true);
        nameBox.addView(name);

        TextView type = new TextView(context);
        type.setText(connectionLabel(d));
        type.setTextSize(11);
        type.setTextColor(MUTED);
        type.setGravity(Gravity.RIGHT);
        nameBox.addView(type);
        top.addView(nameBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView pill = new TextView(context);
        boolean online = isOnline(d);
        boolean modem = isModem(d);
        String pillText = d.blocked ? "بلاک" : (modem ? "Modem" : (online ? "Online" : "Offline"));
        pill.setText(pillText);
        pill.setTextSize(10);
        pill.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(8), dp(5), dp(8), dp(5));
        if (d.blocked) {
            pill.setTextColor(0xFFFFADB5);
            pill.setBackground(bg(0xFF3B1B25, 16, 0xFF632636));
        } else if (modem) {
            pill.setTextColor(0xFFB9DDFF);
            pill.setBackground(bg(0xFF14375C, 16, 0xFF2A68A5));
        } else if (online) {
            pill.setTextColor(0xFF86F0B8);
            pill.setBackground(bg(0xFF123425, 16, 0xFF20563C));
        } else {
            pill.setTextColor(0xFFFFA9B2);
            pill.setBackground(bg(0xFF3B1B25, 16, 0xFF7A3040));
        }
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.setMargins(dp(7), 0, 0, 0);
        top.addView(pill, plp);
        card.addView(top);

        LinearLayout body = new LinearLayout(context);
        body.setOrientation(LinearLayout.HORIZONTAL);
        body.setGravity(Gravity.TOP);
        body.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bodyLp.setMargins(0, dp(7), 0, 0);
        body.setLayoutParams(bodyLp);

        LinearLayout actions = new LinearLayout(context);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.TOP);
        actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // The modem is infrastructure, not a client with a monthly quota.
        // Therefore it never shows the remaining-quota control.
        if (!modem) {
            TextView usage = new TextView(context);
            usage.setText(usageText(d));
            usage.setTextSize(10.5f);
            usage.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            usage.setTextColor(usageTextColor(d));
            usage.setGravity(Gravity.CENTER);
            usage.setSingleLine(true);
            usage.setBackground(bg(usageBackground(d), 11, usageBorder(d)));
            usage.setPadding(dp(5), 0, dp(5), 0);
            usage.setOnClickListener(v -> listener.onUsage(d));
            actions.addView(usage, new LinearLayout.LayoutParams(dp(108), dp(37)));

            View usageGap = new View(context);
            actions.addView(usageGap, new LinearLayout.LayoutParams(1, dp(5)));
        }

        Button rename = button("ویرایش نام", 0xFF183A61, 0xFFB7D9FF);
        rename.setOnClickListener(v -> listener.onRename(d));
        actions.addView(rename, new LinearLayout.LayoutParams(dp(108), dp(37)));

        View spacer = new View(context);
        actions.addView(spacer, new LinearLayout.LayoutParams(1, dp(5)));

        Button block = button(d.blocked ? "رفع بلاک" : "بلاک", d.blocked ? 0xFF123B2B : 0xFF4A1E28, d.blocked ? 0xFF8AF1BB : 0xFFFFA6AF);
        block.setOnClickListener(v -> listener.onToggleBlock(d));
        actions.addView(block, new LinearLayout.LayoutParams(dp(108), dp(37)));
        body.addView(actions);

        View bodyGap = new View(context);
        body.addView(bodyGap, new LinearLayout.LayoutParams(dp(10), 1));

        TextView meta = new TextView(context);
        StringBuilder details = new StringBuilder();
        details.append("IP   ").append(safe(d.ip, "-")).append("\n");
        details.append("MAC   ").append(safe(d.mac, "-")).append("\n");
        details.append("اتصال   ").append(safe(d.iface, "-"));
        String duration = formatDuration(d.connectedTime);
        if (!duration.isEmpty()) details.append("\nمدت اتصال   ").append(duration);
        meta.setText(details.toString());
        meta.setTextSize(12);
        meta.setTextColor(MUTED);
        meta.setLineSpacing(dp(1), 1f);
        meta.setGravity(Gravity.RIGHT);
        meta.setTextDirection(View.TEXT_DIRECTION_RTL);
        body.addView(meta, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        card.addView(body);
        return card;
    }

    private String usageText(Device d) {
        if (d.quotaBytes > 0) {
            long remaining = Math.max(0L, d.quotaBytes - d.usedBytesThisMonth);
            return "مانده " + formatBytes(remaining);
        }
        return "مانده ∞";
    }

    private int usageBackground(Device d) {
        if (d.quotaBytes <= 0) return 0xFF182840;
        long remaining = Math.max(0L, d.quotaBytes - d.usedBytesThisMonth);
        if (remaining == 0) return 0xFF4A1E28;
        if (remaining * 10L <= d.quotaBytes) return 0xFF493716;
        return 0xFF123425;
    }

    private int usageBorder(Device d) {
        if (d.quotaBytes <= 0) return BORDER;
        long remaining = Math.max(0L, d.quotaBytes - d.usedBytesThisMonth);
        if (remaining == 0) return 0xFF7A3040;
        if (remaining * 10L <= d.quotaBytes) return 0xFF80601C;
        return 0xFF20563C;
    }

    private int usageTextColor(Device d) {
        if (d.quotaBytes <= 0) return 0xFFB7D9FF;
        long remaining = Math.max(0L, d.quotaBytes - d.usedBytesThisMonth);
        if (remaining == 0) return 0xFFFFADB5;
        if (remaining * 10L <= d.quotaBytes) return 0xFFFFD27C;
        return 0xFF8AF1BB;
    }

    private boolean isModem(Device d) {
        String mac = safe(d.mac, "").toUpperCase(Locale.ROOT);
        if (mac.isEmpty()) return false;
        return prefs.getBoolean("manual_modem_" + mac, false);
    }

    private static String formatRate(long bytesPerSecond) {
        if (bytesPerSecond <= 0) return "0 B/s";
        if (bytesPerSecond < 1024) return bytesPerSecond + " B/s";
        if (bytesPerSecond < 1024L * 1024L) return String.format(Locale.US, "%.1f KB/s", bytesPerSecond / 1024.0);
        return String.format(Locale.US, "%.1f MB/s", bytesPerSecond / (1024.0 * 1024.0));
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(Locale.US, "%.2f GB", bytes / 1_000_000_000.0);
    }

    private static String formatDuration(String raw) {
        String v = safe(raw, "");
        if (v.isEmpty()) return "";
        try {
            long seconds = Long.parseLong(v);
            if (seconds < 0) return "";
            long days = seconds / 86400;
            long hours = (seconds % 86400) / 3600;
            long minutes = (seconds % 3600) / 60;
            long secs = seconds % 60;
            StringBuilder out = new StringBuilder();
            if (days > 0) out.append(days).append(" روز ");
            if (hours > 0) out.append(hours).append(" ساعت ");
            if (minutes > 0) out.append(minutes).append(" دقیقه ");
            if (days == 0 && hours == 0 && minutes == 0) out.append(secs).append(" ثانیه");
            return out.toString().trim();
        } catch (Exception ignored) {}

        String[] p = v.split(":");
        if (p.length == 2) {
            try {
                long h = Long.parseLong(p[0]);
                long m = Long.parseLong(p[1]);
                if (h > 0) return h + " ساعت " + m + " دقیقه";
                return m + " دقیقه";
            } catch (Exception ignored) {}
        } else if (p.length == 3) {
            try {
                long h = Long.parseLong(p[0]);
                long m = Long.parseLong(p[1]);
                long sec = Long.parseLong(p[2]);
                StringBuilder out = new StringBuilder();
                if (h > 0) out.append(h).append(" ساعت ");
                if (m > 0) out.append(m).append(" دقیقه ");
                if (h == 0 && m == 0) out.append(sec).append(" ثانیه");
                return out.toString().trim();
            } catch (Exception ignored) {}
        }
        return v;
    }

    private static boolean isOnline(Device d) {
        String s = safe(d.status, "").toLowerCase(Locale.ROOT);
        return s.contains("online") || s.equals("1") || s.contains("enable") || s.contains("up") || s.contains("active");
    }

    private static String connectionLabel(Device d) {
        String i = safe(d.iface, "");
        String u = i.toUpperCase(Locale.ROOT);
        if (u.contains("SSID") || u.contains("WIFI") || u.contains("WLAN")) return "Wi‑Fi";
        if (u.contains("LAN") || u.contains("ETH")) return "LAN / Ethernet";
        return i.isEmpty() ? "دستگاه شبکه" : i;
    }

    private static String safe(String s, String def) {
        return s == null || s.trim().isEmpty() || "--".equals(s.trim()) ? def : s.trim();
    }
}
