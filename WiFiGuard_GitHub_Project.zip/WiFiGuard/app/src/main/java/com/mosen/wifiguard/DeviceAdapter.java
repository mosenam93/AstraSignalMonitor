package com.mosen.wifiguard;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DeviceAdapter extends BaseAdapter {
    public interface Listener {
        void onRename(Device d);
        void onToggleBlock(Device d);
    }

    private static final int CARD = 0xFF111C2D;
    private static final int BORDER = 0xFF24344F;
    private static final int TEXT = 0xFFF3F7FC;
    private static final int MUTED = 0xFF94A6BE;
    private static final int BLUE = 0xFF4AA3FF;
    private static final int GREEN = 0xFF28D17C;
    private static final int RED = 0xFFFF5A6A;

    private final Context context;
    private final SharedPreferences prefs;
    private final Listener listener;
    private final List<Device> items = new ArrayList<>();

    public DeviceAdapter(Context context, SharedPreferences prefs, Listener listener) {
        this.context = context;
        this.prefs = prefs;
        this.listener = listener;
    }

    public void setItems(List<Device> devices) {
        items.clear();
        items.addAll(devices);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Device getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    private int dp(int x) { return (int)(x * context.getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private Button button(String text, int color, int textColor) {
        Button b = new Button(context);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setBackground(bg(color, 12, color));
        b.setPadding(dp(10), 0, dp(10), 0);
        return b;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Device d = getItem(position);
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(dp(12), dp(7), dp(12), dp(7));
        card.setLayoutParams(cp);
        card.setBackground(bg(CARD, 18, BORDER));

        LinearLayout top = new LinearLayout(context);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);

        TextView icon = new TextView(context);
        icon.setText(deviceIcon(d));
        icon.setTextSize(24);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(bg(0xFF182840, 14, BORDER));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(48), dp(48));
        ilp.setMargins(dp(10), 0, 0, 0);
        top.addView(icon, ilp);

        LinearLayout nameBox = new LinearLayout(context);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        nameBox.setGravity(Gravity.RIGHT);

        String alias = prefs.getString("alias_" + safe(d.mac, ""), "");
        String shown = alias.isEmpty() ? safe(d.routerName, "دستگاه ناشناس") : alias;

        TextView name = new TextView(context);
        name.setText(shown);
        name.setTextSize(18);
        name.setTextColor(TEXT);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setGravity(Gravity.RIGHT);
        nameBox.addView(name);

        TextView type = new TextView(context);
        type.setText(connectionLabel(d));
        type.setTextSize(12);
        type.setTextColor(MUTED);
        type.setGravity(Gravity.RIGHT);
        nameBox.addView(type);
        top.addView(nameBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        TextView pill = new TextView(context);
        boolean online = isOnline(d);
        String pillText = d.blocked ? "بلاک" : (online ? "Online" : "شناخته‌شده");
        pill.setText(pillText);
        pill.setTextSize(11);
        pill.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(10), dp(6), dp(10), dp(6));
        if (d.blocked) {
            pill.setTextColor(0xFFFFADB5);
            pill.setBackground(bg(0xFF3B1B25, 18, 0xFF632636));
        } else if (online) {
            pill.setTextColor(0xFF86F0B8);
            pill.setBackground(bg(0xFF123425, 18, 0xFF20563C));
        } else {
            pill.setTextColor(0xFFD0D8E5);
            pill.setBackground(bg(0xFF1A273B, 18, BORDER));
        }
        top.addView(pill);
        card.addView(top);

        TextView meta = new TextView(context);
        StringBuilder details = new StringBuilder();
        details.append("IP   ").append(safe(d.ip, "-")).append("\n");
        details.append("MAC   ").append(safe(d.mac, "-")).append("\n");
        if (!alias.isEmpty()) details.append("نام مودم   ").append(safe(d.routerName, "-")).append("\n");
        details.append("اتصال   ").append(safe(d.iface, "-")).append("\n");
        if (!safe(d.connectedTime, "").isEmpty()) details.append("مدت اتصال   ").append(d.connectedTime);
        meta.setText(details.toString().trim());
        meta.setTextSize(13);
        meta.setTextColor(MUTED);
        meta.setLineSpacing(dp(2), 1f);
        meta.setGravity(Gravity.RIGHT);
        meta.setPadding(0, dp(12), 0, dp(12));
        card.addView(meta);

        LinearLayout actions = new LinearLayout(context);
        actions.setGravity(Gravity.RIGHT);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button rename = button("ویرایش نام", 0xFF183A61, 0xFFB7D9FF);
        rename.setOnClickListener(v -> listener.onRename(d));
        actions.addView(rename, new LinearLayout.LayoutParams(0, dp(44), 1));

        View spacer = new View(context);
        actions.addView(spacer, new LinearLayout.LayoutParams(dp(8), 1));

        Button block = button(d.blocked ? "رفع بلاک" : "بلاک", d.blocked ? 0xFF123B2B : 0xFF4A1E28, d.blocked ? 0xFF8AF1BB : 0xFFFFA6AF);
        block.setOnClickListener(v -> listener.onToggleBlock(d));
        actions.addView(block, new LinearLayout.LayoutParams(0, dp(44), 1));
        card.addView(actions);
        return card;
    }

    private static boolean isOnline(Device d) {
        String s = safe(d.status, "").toLowerCase(Locale.ROOT);
        return s.contains("online") || s.equals("1") || s.contains("enable") || s.contains("up");
    }

    private static String connectionLabel(Device d) {
        String i = safe(d.iface, "");
        String u = i.toUpperCase(Locale.ROOT);
        if (u.contains("SSID") || u.contains("WIFI") || u.contains("WLAN")) return "Wi‑Fi";
        if (u.contains("LAN") || u.contains("ETH")) return "LAN / Ethernet";
        return i.isEmpty() ? "دستگاه شبکه" : i;
    }

    private static String deviceIcon(Device d) {
        String n = (safe(d.routerName, "") + " " + safe(d.iface, "")).toLowerCase(Locale.ROOT);
        if (n.contains("tv") || n.contains("television")) return "📺";
        if (n.contains("laptop") || n.contains("pc") || n.contains("computer") || n.contains("windows")) return "💻";
        if (n.contains("printer")) return "🖨";
        if (n.contains("camera")) return "📷";
        if (n.contains("phone") || n.contains("android") || n.contains("iphone") || n.contains("mobile")) return "📱";
        return "◉";
    }

    private static String safe(String s, String def) {
        return s == null || s.trim().isEmpty() || "--".equals(s.trim()) ? def : s.trim();
    }
}
