package com.mosen.wifiguard;

import android.util.Base64;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HuaweiRouterClient {
    private static final String DEVINFO_PATH = "/html/bbsp/userdevinfo/getuserdevinfo.asp";
    private static final String MAC_FILTER_PATH = "/html/bbsp/macfilter/macfilter.asp";
    private static final String MAC_FILTER_ADD_PATH = "/html/bbsp/macfilter/add.cgi";
    private static final String MAC_FILTER_DEL_PATH = "/html/bbsp/macfilter/del.cgi";
    private static final String MAC_FILTER_SET_PATH = "/html/bbsp/macfilter/set.cgi";
    private static final String MAC_FILTER_DOMAIN = "InternetGatewayDevice.X_HW_Security.MacFilter";

    private final String baseUrl;
    private final String username;
    private final String password;
    private final CookieManager cookieManager = new CookieManager();

    private static final Pattern DEVINFO_CALL = Pattern.compile("stUserDevInfoPTVDF\\(([^)]*)\\)");
    private static final Pattern MAC_ENTRY = Pattern.compile("stMacFilter\\(([^)]*)\\)");
    private static final Pattern QUOTED = Pattern.compile("\\\"((?:[^\\\"\\\\]|\\\\.)*)\\\"");
    private static final Pattern HEX = Pattern.compile("\\\\x([0-9a-fA-F]{2})");
    private static final Pattern TOKEN = Pattern.compile("id=\\\"hwonttoken\\\"\\s+value=\\\"([0-9a-fA-F]+)\\\"");
    private static final Pattern ENABLED = Pattern.compile("var enableFilter = '(\\d)'");
    private static final Pattern MODE = Pattern.compile("var Mode = '(\\d)'");

    public HuaweiRouterClient(String host, String username, String password) {
        String h = host.trim();
        if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://" + h;
        while (h.endsWith("/")) h = h.substring(0, h.length() - 1);
        this.baseUrl = h;
        this.username = username;
        this.password = password;
        CookieHandler.setDefault(cookieManager);
    }

    public void login() throws Exception {
        request("GET", "/", null, null);
        String token = request("POST", "/asp/GetRandCount.asp", "", null).trim().replace("\uFEFF", "");
        if (token.isEmpty()) throw new IOException("توکن ورود از مودم دریافت نشد.");

        String pass64 = Base64.encodeToString(password.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        Map<String, String> f = new LinkedHashMap<>();
        f.put("UserName", username);
        f.put("PassWord", pass64);
        f.put("Language", "english");
        f.put("x.X_HW_Token", token);
        String html = request("POST", "/login.cgi", formEncode(f), baseUrl + "/");
        if (html.contains("txt_Username") || html.contains("txt_Password")) {
            throw new IOException("نام کاربری یا رمز مودم اشتباه است، یا ورود موقتاً قفل شده.");
        }
    }

    public List<Device> getDevices() throws Exception {
        String html = request("POST", DEVINFO_PATH, "", null);
        LinkedHashMap<String, Device> unique = new LinkedHashMap<>();
        Matcher m = DEVINFO_CALL.matcher(html);
        while (m.find()) {
            List<String> args = quotedArgs(m.group(1));
            if (args.size() < 9) continue;
            String name = args.get(0);
            String ip = args.get(2);
            String mac = args.get(3);
            String status = args.get(5);
            String iface = args.get(6);
            String connected = args.get(7);
            String key = (mac == null || mac.isEmpty()) ? name : mac.toLowerCase(Locale.ROOT);
            if (!unique.containsKey(key)) {
                unique.put(key, new Device(name, ip, mac, status, iface, connected));
            }
        }
        MacFilterStatus fs = getMacFilterStatus();
        for (Device d : unique.values()) {
            d.blocked = fs.containsMac(d.mac);
        }
        return new ArrayList<>(unique.values());
    }

    public MacFilterStatus getMacFilterStatus() throws Exception {
        String html = request("GET", MAC_FILTER_PATH, null, null);
        boolean enabled = false;
        String mode = "blacklist";
        Matcher em = ENABLED.matcher(html);
        if (em.find()) enabled = "1".equals(em.group(1));
        Matcher mm = MODE.matcher(html);
        if (mm.find()) mode = "1".equals(mm.group(1)) ? "whitelist" : "blacklist";
        String token = extractToken(html);

        List<MacEntry> entries = new ArrayList<>();
        Matcher e = MAC_ENTRY.matcher(html);
        while (e.find()) {
            List<String> args = quotedArgs(e.group(1));
            if (args.size() >= 3) entries.add(new MacEntry(args.get(0), args.get(1), args.get(2)));
        }
        return new MacFilterStatus(enabled, mode, token, entries);
    }

    public void ensureBlacklistEnabled() throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        if (s.enabled && "blacklist".equals(s.mode)) return;
        Map<String, String> f = new LinkedHashMap<>();
        f.put("x.MacFilterRight", "1");
        f.put("x.MacFilterPolicy", "0");
        f.put("x.X_HW_Token", s.token);
        String url = MAC_FILTER_SET_PATH + "?x=InternetGatewayDevice.X_HW_Security&RequestFile=" + MAC_FILTER_PATH.substring(1);
        request("POST", url, formEncode(f), baseUrl + MAC_FILTER_PATH);
    }

    public void block(Device d, String alias) throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        if (!s.enabled || !"blacklist".equals(s.mode)) {
            throw new IOException("MAC Filter باید در حالت Blacklist فعال باشد.");
        }
        if (s.containsMac(d.mac)) return;
        Map<String, String> f = new LinkedHashMap<>();
        f.put("x.SourceMACAddress", d.mac);
        f.put("x.DeviceAlias", alias == null ? "" : alias);
        f.put("x.X_HW_Token", s.token);
        String url = MAC_FILTER_ADD_PATH + "?x=" + MAC_FILTER_DOMAIN + "&RequestFile=" + MAC_FILTER_PATH.substring(1);
        request("POST", url, formEncode(f), baseUrl + MAC_FILTER_PATH);
    }

    public void unblock(Device d) throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        MacEntry found = null;
        for (MacEntry e : s.entries) {
            if (e.mac.equalsIgnoreCase(d.mac)) { found = e; break; }
        }
        if (found == null) return;
        Map<String, String> f = new LinkedHashMap<>();
        f.put(found.domain, "");
        f.put("x.X_HW_Token", s.token);
        String url = MAC_FILTER_DEL_PATH + "?x=" + MAC_FILTER_DOMAIN + "&RequestFile=" + MAC_FILTER_PATH.substring(1);
        request("POST", url, formEncode(f), baseUrl + MAC_FILTER_PATH);
    }

    private String request(String method, String path, String body, String referer) throws Exception {
        URL url = new URL(path.startsWith("http") ? path : baseUrl + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(12000);
        c.setRequestMethod(method);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android; WiFiGuard/1.0)");
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*");
        if (referer != null) c.setRequestProperty("Referer", referer);
        if ("POST".equals(method)) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            byte[] bytes = (body == null ? "" : body).getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
        String text = readAll(is);
        c.disconnect();
        if (code < 200 || code >= 400) throw new IOException("خطای مودم: HTTP " + code);
        return text;
    }

    private static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private static String formEncode(Map<String, String> map) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : map.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), "UTF-8"));
            sb.append('=');
            sb.append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }
        return sb.toString();
    }

    private static List<String> quotedArgs(String call) {
        ArrayList<String> out = new ArrayList<>();
        Matcher m = QUOTED.matcher(call);
        while (m.find()) out.add(decodeHex(m.group(1)));
        return out;
    }

    private static String decodeHex(String s) {
        Matcher m = HEX.matcher(s);
        StringBuffer b = new StringBuffer();
        while (m.find()) {
            char ch = (char) Integer.parseInt(m.group(1), 16);
            m.appendReplacement(b, Matcher.quoteReplacement(String.valueOf(ch)));
        }
        m.appendTail(b);
        return b.toString().replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private static String extractToken(String html) throws IOException {
        Matcher m = TOKEN.matcher(html);
        if (!m.find()) throw new IOException("توکن امنیتی صفحه MAC Filter پیدا نشد.");
        return m.group(1);
    }

    public static class MacEntry {
        public final String domain, mac, alias;
        MacEntry(String domain, String mac, String alias) {
            this.domain = domain; this.mac = mac; this.alias = alias;
        }
    }

    public static class MacFilterStatus {
        public final boolean enabled;
        public final String mode;
        public final String token;
        public final List<MacEntry> entries;
        MacFilterStatus(boolean enabled, String mode, String token, List<MacEntry> entries) {
            this.enabled = enabled; this.mode = mode; this.token = token; this.entries = entries;
        }
        public boolean containsMac(String mac) {
            if (mac == null) return false;
            for (MacEntry e : entries) if (e.mac.equalsIgnoreCase(mac)) return true;
            return false;
        }
    }
}
