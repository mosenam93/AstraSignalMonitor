package com.mosen.wifiguard;

import android.util.Base64;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HuaweiRouterClient {
    private static final String[] DEVICE_PATHS = new String[] {
            "/html/bbsp/common/GetLanUserDevInfo.asp",
            "/html/bbsp/userdevinfo/getuserdevinfo.asp",
            "/GetLanUserDevInfo.asp",
            "/html/bbsp/arp/arp.asp",
            "/html/bbsp/dhcpserver/dhcpserver.asp",
            "/html/bbsp/home/home.asp",
            "/html/index.asp"
    };

    private static final String WLAN_MAC_FILTER_PATH = "/html/bbsp/wlanmacfilter/wlanmacfilter.asp";
    private static final String LAN_MAC_FILTER_PATH = "/html/bbsp/macfilter/macfilter.asp";

    private final String baseUrl;
    private final String username;
    private final String password;
    private String lastDeviceSource = "";
    private String manualCookie = "";

    private static final Pattern PTVDF_CALL = Pattern.compile("(?:new\\s+)?stUserDevInfoPTVDF\\s*\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern USER_DEVICE_CALL = Pattern.compile("(?:new\\s+)?USERDevice(?:New)?\\s*\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern MAC_ENTRY = Pattern.compile("(?:new\\s+)?stMacFilter\\s*\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern QUOTED = Pattern.compile("[\"']((?:[^\"'\\\\]|\\\\.)*)[\"']", Pattern.DOTALL);
    private static final Pattern HEX = Pattern.compile("\\\\x([0-9a-fA-F]{2})");
    private static final Pattern INPUT_TAG = Pattern.compile("(?is)<input\\b[^>]*(?:id|name)\\s*=\\s*[\"']?(?:hwonttoken|onttoken)[\"']?[^>]*>");
    private static final Pattern VALUE_ATTR = Pattern.compile("(?i)\\bvalue\\s*=\\s*[\"']?([^\"'\\s>]+)");
    private static final Pattern TOKEN_FALLBACK = Pattern.compile("(?i)(?:hwonttoken|onttoken)[^>\\n]{0,180}?value\\s*=\\s*[\"']([^\"']+)[\"']");
    private static final Pattern ENABLED = Pattern.compile("(?i)var\\s+(?:enableFilter|WlanMacFilterRight)\\s*=\\s*['\"]?(\\d)['\"]?");
    private static final Pattern MODE = Pattern.compile("(?i)var\\s+(?:Mode|WlanMacFilterPolicy)\\s*=\\s*['\"]?(\\d)['\"]?");
    private static final Pattern MAC_RE = Pattern.compile("(?i)^[0-9a-f]{2}(?::[0-9a-f]{2}){5}$");
    private static final Pattern MAC_LOOSE = Pattern.compile("(?i)[0-9a-f]{2}(?:[:-][0-9a-f]{2}){5}");
    private static final Pattern IP_PRIVATE = Pattern.compile("(?<!\\d)(?:192\\.168\\.\\d{1,3}\\.\\d{1,3}|10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.(?:1[6-9]|2\\d|3[0-1])\\.\\d{1,3}\\.\\d{1,3})(?!\\d)");

    public HuaweiRouterClient(String host, String username, String password) {
        String h = host.trim();
        if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://" + h;
        while (h.endsWith("/")) h = h.substring(0, h.length() - 1);
        this.baseUrl = h;
        this.username = username;
        this.password = password;
    }

    public String getLastDeviceSource() {
        return lastDeviceSource;
    }

    public void login() throws Exception {
        // HG8546M's own login JavaScript explicitly installs this cookie before
        // requesting the challenge and submitting /login.cgi. Without it the
        // router may answer HTTP 200 but not create an authenticated session.
        request("GET", "/", null, null);
        manualCookie = "Cookie=body:Language:english:id=-1";

        String token = request("POST", "/asp/GetRandCount.asp", "", baseUrl + "/").trim().replace("\uFEFF", "");
        if (token.isEmpty()) throw new IOException("توکن ورود از مودم دریافت نشد.");

        String pass64 = Base64.encodeToString(password.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        Map<String, String> f = new LinkedHashMap<>();
        f.put("UserName", username);
        f.put("PassWord", pass64);
        f.put("Language", "english");
        f.put("x.X_HW_Token", token);

        String html = request("POST", "/login.cgi", formEncode(f), baseUrl + "/");
        if (looksLikeLoginPage(html)) {
            throw new IOException("نام کاربری یا رمز مودم اشتباه است، یا ورود موقتاً قفل شده.");
        }

        // Do not treat login.cgi HTTP 200 as success. Verify a protected page.
        String verify = request("GET", "/index.asp", null, baseUrl + "/login.cgi");
        if (looksLikeLoginPage(verify)) {
            throw new IOException("ورود توسط مودم تأیید نشد. نام کاربری/رمز یا نشست ورود را بررسی کن.");
        }

        // A valid session on this firmware normally changes the initial
        // Cookie=body:...:id=-1 value into an authenticated cookie/id.
        if (manualCookie.contains("id=-1") && !verify.toLowerCase(Locale.ROOT).contains("logout")) {
            throw new IOException("مودم نشست ورود معتبر ایجاد نکرد. دوباره تلاش کن.");
        }
    }

    public List<Device> getDevices() throws Exception {
        LinkedHashMap<String, Device> unique = new LinkedHashMap<>();
        List<String> diag = new ArrayList<>();

        String[][] attempts = new String[][] {
                {"POST", "/html/bbsp/userdevinfo/getuserdevinfo.asp", "/html/bbsp/userdevinfo/userdevinfo1.asp"},
                {"GET",  "/html/bbsp/common/GetLanUserDevInfo.asp", "/CustomApp/mainpage.asp"},
                {"POST", "/html/bbsp/common/GetLanUserDevInfo.asp", "/CustomApp/mainpage.asp"},
                {"GET",  "/html/bbsp/common/GetLanUserDevInfo.asp", "/index.asp"},
                {"POST", "/html/bbsp/common/GetLanUserDevInfo.asp", "/index.asp"},
                {"GET",  "/html/bbsp/userdevinfo/userdevinfo1.asp", "/index.asp"},
                {"GET",  "/html/bbsp/arp/arp.asp", "/index.asp"},
                {"GET",  "/html/bbsp/dhcpserver/dhcpserver.asp", "/index.asp"}
        };

        for (String[] a : attempts) {
            String method = a[0];
            String path = a[1];
            String referer = baseUrl + a[2];
            try {
                String html = request(method, path, "POST".equals(method) ? "" : null, referer);
                if (looksLikeLoginPage(html)) {
                    diag.add(shortSource(path, method) + "=login");
                    continue;
                }

                int before = unique.size();
                parsePtvdf(html, unique);
                parseUserDevice(html, unique);
                parseGeneric(html, unique);
                int added = unique.size() - before;
                diag.add(shortSource(path, method) + "=" + added);
                if (added > 0) {
                    lastDeviceSource = shortSource(path, method);
                    break;
                }
            } catch (Exception e) {
                diag.add(shortSource(path, method) + "=" + safeMessage(e));
            }
        }

        if (unique.isEmpty()) {
            List<Device> scanned = scanLanByArp();
            for (Device d : scanned) addDevice(unique, d);
            if (!scanned.isEmpty()) lastDeviceSource = "اسکن محلی شبکه / ARP";
        }

        if (unique.isEmpty()) {
            lastDeviceSource = "ورود تأیید شد؛ لیست مودم خالی/ناسازگار است";
            if (!diag.isEmpty()) lastDeviceSource += " [" + String.join(" | ", diag) + "]";
        }

        try {
            MacFilterStatus fs = getMacFilterStatus();
            for (Device d : unique.values()) d.blocked = fs.containsMac(d.mac);
        } catch (Exception ignored) {
            for (Device d : unique.values()) d.blocked = false;
        }

        return new ArrayList<>(unique.values());
    }

    private List<Device> scanLanByArp() {
        ArrayList<Device> out = new ArrayList<>();
        String routerIp = getRouterIp();
        String prefix = getPrefix(routerIp);
        if (prefix.isEmpty()) return out;

        List<Device> firstPass = readArpTable(prefix, routerIp);
        if (!firstPass.isEmpty()) return firstPass;

        probeSubnet(prefix, routerIp);
        return readArpTable(prefix, routerIp);
    }

    private void probeSubnet(String prefix, String routerIp) {
        ExecutorService pool = Executors.newFixedThreadPool(48);
        for (int i = 2; i <= 254; i++) {
            final String ip = prefix + "." + i;
            if (ip.equals(routerIp)) continue;
            pool.execute(() -> probeHost(ip));
        }
        pool.shutdown();
        try {
            pool.awaitTermination(12, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
    }

    private void probeHost(String ip) {
        int[] ports = new int[] {80, 443, 53, 22};
        for (int port : ports) {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(ip, port), 140);
                return;
            } catch (Exception ignored) {
            }
        }
        try {
            InetAddress.getByName(ip).isReachable(180);
        } catch (Exception ignored) {
        }
    }

    private List<Device> readArpTable(String prefix, String routerIp) {
        LinkedHashMap<String, Device> unique = new LinkedHashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/net/arp"))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("IP address")) continue;
                String[] p = line.split("\\s+");
                if (p.length < 4) continue;
                String ip = p[0].trim();
                String mac = normalizeMac(p[3]);
                String iface = p.length >= 6 ? p[5].trim() : "wlan0";
                if (!ip.startsWith(prefix + ".")) continue;
                if (ip.equals(routerIp)) continue;
                if (!isMac(mac)) continue;
                if ("00:00:00:00:00:00".equals(mac)) continue;
                String name = "دستگاه شبکه";
                addDevice(unique, new Device(name, ip, mac, "فعال", "ARP / " + iface, ""));
            }
        } catch (Exception ignored) {
        }
        return new ArrayList<>(unique.values());
    }

    private static String shortSource(String path, String method) {
        if (path.contains("GetLanUserDevInfo")) return "GetLanUserDevInfo / " + method;
        if (path.contains("getuserdevinfo")) return "userdevinfo / " + method;
        if (path.contains("arp")) return "arp / " + method;
        if (path.contains("dhcp")) return "dhcp / " + method;
        return path + " / " + method;
    }

    private void parsePtvdf(String html, LinkedHashMap<String, Device> unique) {
        Matcher m = PTVDF_CALL.matcher(html == null ? "" : html);
        while (m.find()) {
            List<String> a = quotedArgs(m.group(1));
            if (a.size() < 4) continue;
            String name = get(a, 0);
            String ip = get(a, 2);
            String mac = normalizeMac(get(a, 3));
            String status = get(a, 5);
            String iface = get(a, 6);
            String connected = get(a, 7);
            addDevice(unique, new Device(name, ip, mac, status, iface, connected));
        }
    }

    private void parseUserDevice(String html, LinkedHashMap<String, Device> unique) {
        Matcher m = USER_DEVICE_CALL.matcher(html == null ? "" : html);
        while (m.find()) {
            List<String> a = quotedArgs(m.group(1));
            if (a.size() < 3) continue;

            String ip = get(a, 1);
            String mac = normalizeMac(get(a, 2));
            if (!isMac(mac)) {
                for (String v : a) {
                    String candidate = normalizeMac(v);
                    if (isMac(candidate)) { mac = candidate; break; }
                }
            }

            String iface = firstNonEmpty(get(a, 7), get(a, 3));
            String status = get(a, 6);
            String connected = get(a, 8);
            String hostName = get(a, 9);
            String alias = get(a, 13);
            String devType = get(a, 5);
            String name = firstNonEmpty(hostName, alias, devType, iface, "دستگاه ناشناس");

            addDevice(unique, new Device(name, ip, mac, status, iface, connected));
        }
    }

    private void parseGeneric(String html, LinkedHashMap<String, Device> unique) {
        if (html == null || html.isEmpty()) return;
        String[] lines = html.split("\n");
        for (String line : lines) {
            String mac = firstMac(line);
            String ip = firstPrivateIp(line);
            if (!isMac(mac) || ip.isEmpty() || ip.equals(getRouterIp())) continue;
            String name = extractFriendlyName(line);
            addDevice(unique, new Device(name, ip, mac, "فعال", "Generic Parse", ""));
        }
    }

    private static String extractFriendlyName(String line) {
        if (line == null) return "دستگاه شبکه";
        String cleaned = line.replaceAll("<[^>]+>", " ")
                .replace("&nbsp;", " ")
                .replaceAll("\\s+", " ")
                .trim();
        if (cleaned.isEmpty()) return "دستگاه شبکه";
        String[] banned = {"MAC", "IP", "SSID", "Status", "Hostname", "Device", "User", "Index"};
        for (String b : banned) cleaned = cleaned.replace(b, " ");
        cleaned = cleaned.replaceAll("[0-9A-Fa-f]{2}(?::|\\-){1}[0-9A-Fa-f:\\-]{14,}", " ")
                .replaceAll("\\b(?:192\\.168\\.\\d{1,3}\\.\\d{1,3}|10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.(?:1[6-9]|2\\d|3[0-1])\\.\\d{1,3}\\.\\d{1,3})\\b", " ")
                .replaceAll("\\s+", " ").trim();
        return cleaned.isEmpty() ? "دستگاه شبکه" : cleaned;
    }

    private static String firstMac(String text) {
        Matcher m = MAC_LOOSE.matcher(text == null ? "" : text);
        return m.find() ? normalizeMac(m.group()) : "";
    }

    private static String firstPrivateIp(String text) {
        Matcher m = IP_PRIVATE.matcher(text == null ? "" : text);
        return m.find() ? m.group() : "";
    }

    private static void addDevice(LinkedHashMap<String, Device> unique, Device d) {
        if (d == null) return;
        String mac = normalizeMac(d.mac);
        d.mac = mac;
        String ip = d.ip == null ? "" : d.ip.trim();
        if (mac.isEmpty() && ip.isEmpty()) return;

        String key = !mac.isEmpty() ? mac.toLowerCase(Locale.ROOT) : ip;
        Device old = unique.get(key);
        if (old == null) {
            unique.put(key, d);
            return;
        }

        if (isBlank(old.routerName) && !isBlank(d.routerName)) old.routerName = d.routerName;
        if (isBlank(old.ip) && !isBlank(d.ip)) old.ip = d.ip;
        if (isBlank(old.status) && !isBlank(d.status)) old.status = d.status;
        if (isBlank(old.iface) && !isBlank(d.iface)) old.iface = d.iface;
        if (isBlank(old.connectedTime) && !isBlank(d.connectedTime)) old.connectedTime = d.connectedTime;
    }

    public MacFilterStatus getMacFilterStatus() throws Exception {
        Exception firstError = null;
        try {
            return readMacFilter(WLAN_MAC_FILTER_PATH, true);
        } catch (Exception e) {
            firstError = e;
        }
        try {
            return readMacFilter(LAN_MAC_FILTER_PATH, false);
        } catch (Exception e) {
            String a = firstError == null ? "" : safeMessage(firstError);
            String b = safeMessage(e);
            throw new IOException("صفحه MAC Filter این فریمور پیدا/خوانده نشد. WLAN: " + a + " | LAN: " + b);
        }
    }

    private MacFilterStatus readMacFilter(String path, boolean wlan) throws Exception {
        String html = request("GET", path, null, baseUrl + "/index.asp");
        if (looksLikeLoginPage(html)) throw new IOException("نشست ورود منقضی شده");

        String token = extractToken(html);
        boolean enabled = false;
        String mode = "blacklist";
        Matcher em = ENABLED.matcher(html);
        if (em.find()) enabled = "1".equals(em.group(1));
        Matcher mm = MODE.matcher(html);
        if (mm.find()) mode = "1".equals(mm.group(1)) ? "whitelist" : "blacklist";

        List<MacEntry> entries = new ArrayList<>();
        Matcher e = MAC_ENTRY.matcher(html);
        while (e.find()) {
            List<String> args = quotedArgs(e.group(1));
            if (args.isEmpty()) continue;
            String domain = decodeHex(args.get(0));
            String mac = "";
            String alias = "";
            for (int i = 1; i < args.size(); i++) {
                String v = decodeHex(args.get(i)).trim();
                String nm = normalizeMac(v);
                if (isMac(nm)) mac = nm;
                else if (!v.isEmpty()) alias = v;
            }
            if (!domain.isEmpty() && !mac.isEmpty()) entries.add(new MacEntry(domain, mac, alias));
        }
        return new MacFilterStatus(enabled, mode, token, entries, path, wlan);
    }

    public void ensureBlacklistEnabled() throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        if (s.enabled && "blacklist".equals(s.mode)) return;

        Map<String, String> f = new LinkedHashMap<>();
        f.put(s.wlan ? "x.WlanMacFilterRight" : "x.MacFilterRight", "1");
        f.put(s.wlan ? "x.WlanMacFilterPolicy" : "x.MacFilterPolicy", "0");
        f.put("x.X_HW_Token", s.token);

        String folder = s.wlan ? "/html/bbsp/wlanmacfilter" : "/html/bbsp/macfilter";
        String url = folder + "/set.cgi?x=InternetGatewayDevice.X_HW_Security&RequestFile=" + s.path.substring(1);
        request("POST", url, formEncode(f), baseUrl + s.path);
    }

    public void block(Device d, String alias) throws Exception {
        if (d == null || !isMac(normalizeMac(d.mac))) throw new IOException("MAC این دستگاه معتبر نیست.");
        MacFilterStatus s = getMacFilterStatus();
        if (!s.enabled || !"blacklist".equals(s.mode)) {
            throw new IOException("MAC Filter باید در حالت Blacklist فعال باشد.");
        }
        if (s.containsMac(d.mac)) return;

        Map<String, String> f = new LinkedHashMap<>();
        f.put("x.SourceMACAddress", normalizeMac(d.mac));
        if (s.wlan) {
            f.put("x.SSIDName", guessSsidName(d));
            f.put("x.Enable", "1");
        } else {
            f.put("x.DeviceAlias", alias == null ? "" : alias);
        }
        f.put("x.X_HW_Token", s.token);

        String folder = s.wlan ? "/html/bbsp/wlanmacfilter" : "/html/bbsp/macfilter";
        String domain = s.wlan ? "InternetGatewayDevice.X_HW_Security.WLANMacFilter" : "InternetGatewayDevice.X_HW_Security.MacFilter";
        String url = folder + "/add.cgi?x=" + domain + "&RequestFile=" + s.path.substring(1);
        request("POST", url, formEncode(f), baseUrl + s.path);
    }

    public void unblock(Device d) throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        MacEntry found = null;
        for (MacEntry e : s.entries) {
            if (e.mac.equalsIgnoreCase(normalizeMac(d.mac))) { found = e; break; }
        }
        if (found == null) return;

        Map<String, String> f = new LinkedHashMap<>();
        f.put(found.domain, "");
        f.put("x.X_HW_Token", s.token);

        String folder = s.wlan ? "/html/bbsp/wlanmacfilter" : "/html/bbsp/macfilter";
        String domain = s.wlan ? "InternetGatewayDevice.X_HW_Security.WLANMacFilter" : "InternetGatewayDevice.X_HW_Security.MacFilter";
        String url = folder + "/del.cgi?x=" + domain + "&RequestFile=" + s.path.substring(1);
        request("POST", url, formEncode(f), baseUrl + s.path);
    }

    private String guessSsidName(Device d) {
        String iface = d == null ? "" : d.iface;
        if (iface != null && iface.toUpperCase(Locale.ROOT).startsWith("SSID")) return iface;
        return "SSID-1";
    }

    private String getRouterIp() {
        try {
            URL url = new URL(baseUrl);
            String host = url.getHost();
            return host == null ? "" : host.trim();
        } catch (Exception e) {
            return "";
        }
    }

    private String getPrefix(String ip) {
        if (ip == null) return "";
        int idx = ip.lastIndexOf('.');
        return idx > 0 ? ip.substring(0, idx) : "";
    }

    private String request(String method, String path, String body, String referer) throws Exception {
        URL url = new URL(path.startsWith("http") ? path : baseUrl + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(12000);
        c.setRequestMethod(method);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*");
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        c.setRequestProperty("Accept-Encoding", "identity");
        c.setRequestProperty("Connection", "keep-alive");
        c.setRequestProperty("Origin", baseUrl);
        c.setRequestProperty("X-Requested-With", "XMLHttpRequest");
        if (referer != null) c.setRequestProperty("Referer", referer);
        if (manualCookie != null && !manualCookie.isEmpty()) c.setRequestProperty("Cookie", manualCookie);

        if ("POST".equals(method)) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            byte[] bytes = (body == null ? "" : body).getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        }

        int code = c.getResponseCode();
        captureCookies(c);
        InputStream is = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
        String text = readAll(is);
        c.disconnect();
        if (code < 200 || code >= 400) throw new IOException("HTTP " + code);
        return text;
    }

    private void captureCookies(HttpURLConnection c) {
        try {
            Map<String, List<String>> headers = c.getHeaderFields();
            if (headers == null) return;
            LinkedHashMap<String, String> cookies = new LinkedHashMap<>();

            if (manualCookie != null && !manualCookie.isEmpty()) {
                for (String part : manualCookie.split(";\\s*")) {
                    int eq = part.indexOf('=');
                    if (eq > 0) cookies.put(part.substring(0, eq).trim(), part.substring(eq + 1).trim());
                }
            }

            for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
                String key = entry.getKey();
                if (key == null || !"set-cookie".equalsIgnoreCase(key)) continue;
                for (String raw : entry.getValue()) {
                    if (raw == null) continue;
                    String nv = raw.split(";", 2)[0].trim();
                    int eq = nv.indexOf('=');
                    if (eq > 0) cookies.put(nv.substring(0, eq).trim(), nv.substring(eq + 1).trim());
                }
            }

            if (!cookies.isEmpty()) {
                StringBuilder b = new StringBuilder();
                for (Map.Entry<String, String> e : cookies.entrySet()) {
                    if (b.length() > 0) b.append("; ");
                    b.append(e.getKey()).append('=').append(e.getValue());
                }
                manualCookie = b.toString();
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean looksLikeLoginPage(String html) {
        if (html == null || html.isEmpty()) return false;
        String h = html.toLowerCase(Locale.ROOT);
        return (h.contains("txt_username") && h.contains("txt_password")) ||
                (h.contains("login.cgi") && h.contains("type=\"password\""));
    }

    private static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private static String formEncode(Map<String, String> map) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : map.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), "UTF-8"));
            sb.append('=');
            sb.append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }
        return sb.toString();
    }

    private static List<String> quotedArgs(String call) {
        ArrayList<String> out = new ArrayList<>();
        Matcher m = QUOTED.matcher(call == null ? "" : call);
        while (m.find()) out.add(decodeHex(m.group(1)));
        return out;
    }

    private static String decodeHex(String s) {
        Matcher m = HEX.matcher(s == null ? "" : s);
        StringBuffer b = new StringBuffer();
        while (m.find()) {
            char ch = (char) Integer.parseInt(m.group(1), 16);
            m.appendReplacement(b, Matcher.quoteReplacement(String.valueOf(ch)));
        }
        m.appendTail(b);
        return b.toString().replace("\\\"", "\"").replace("\\'", "'").replace("\\\\", "\\");
    }

    private static String extractToken(String html) throws IOException {
        Matcher tag = INPUT_TAG.matcher(html == null ? "" : html);
        while (tag.find()) {
            Matcher v = VALUE_ATTR.matcher(tag.group());
            if (v.find() && !v.group(1).trim().isEmpty()) return v.group(1).trim();
        }
        Matcher f = TOKEN_FALLBACK.matcher(html == null ? "" : html);
        if (f.find() && !f.group(1).trim().isEmpty()) return f.group(1).trim();
        throw new IOException("توکن امنیتی در صفحه پیدا نشد");
    }

    private static String normalizeMac(String value) {
        if (value == null) return "";
        String v = decodeHex(value).trim().replace('-', ':').toUpperCase(Locale.ROOT);
        Matcher m = MAC_LOOSE.matcher(v);
        return m.find() ? m.group().replace('-', ':').toUpperCase(Locale.ROOT) : value.trim();
    }

    private static boolean isMac(String value) {
        return value != null && MAC_RE.matcher(value).matches();
    }

    private static String get(List<String> a, int i) {
        return i >= 0 && i < a.size() ? decodeHex(a.get(i)).trim() : "";
    }

    private static String firstNonEmpty(String... values) {
        if (values == null) return "";
        for (String s : values) if (!isBlank(s) && !"--".equals(s)) return s.trim();
        return "";
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty() || "--".equals(s.trim());
    }

    private static String safeMessage(Throwable e) {
        if (e == null) return "error";
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    public static class MacEntry {
        public final String domain, mac, alias;
        MacEntry(String domain, String mac, String alias) {
            this.domain = domain; this.mac = mac; this.alias = alias;
        }
    }

    public static class MacFilterStatus {
        public final boolean enabled;
        public final String mode;
        public final String token;
        public final List<MacEntry> entries;
        public final String path;
        public final boolean wlan;

        MacFilterStatus(boolean enabled, String mode, String token, List<MacEntry> entries, String path, boolean wlan) {
            this.enabled = enabled;
            this.mode = mode;
            this.token = token;
            this.entries = entries;
            this.path = path;
            this.wlan = wlan;
        }

        public boolean containsMac(String mac) {
            if (mac == null) return false;
            String target = normalizeMac(mac);
            for (MacEntry e : entries) if (e.mac.equalsIgnoreCase(target)) return true;
            return false;
        }
    }
}
