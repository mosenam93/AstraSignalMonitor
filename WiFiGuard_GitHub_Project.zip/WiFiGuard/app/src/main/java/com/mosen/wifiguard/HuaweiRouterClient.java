package com.mosen.wifiguard;

import android.util.Base64;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HuaweiRouterClient {
    private static final String DEVINFO_PATH = "/html/bbsp/userdevinfo/getuserdevinfo.asp";

    // Huawei firmwares use one of these two MAC-filter pages.
    // HG/EG ONTs often expose the Wi-Fi-specific page (wlanmacfilter.asp).
    private static final String WLAN_MAC_FILTER_PATH = "/html/bbsp/wlanmacfilter/wlanmacfilter.asp";
    private static final String LAN_MAC_FILTER_PATH = "/html/bbsp/macfilter/macfilter.asp";

    private final String baseUrl;
    private final String username;
    private final String password;
    private final CookieManager cookieManager = new CookieManager();

    private static final Pattern DEVINFO_CALL = Pattern.compile("stUserDevInfoPTVDF\\(([^)]*)\\)");
    private static final Pattern MAC_ENTRY = Pattern.compile("(?:new\\s+)?stMacFilter\\s*\\(([^)]*)\\)", Pattern.CASE_INSENSITIVE);
    private static final Pattern QUOTED = Pattern.compile("[\\\"']((?:[^\\\"'\\\\]|\\\\.)*)[\\\"']");
    private static final Pattern HEX = Pattern.compile("\\\\x([0-9a-fA-F]{2})");
    private static final Pattern INPUT_TAG = Pattern.compile("(?is)<input\\b[^>]*(?:id|name)\\s*=\\s*[\\\"']?(?:hwonttoken|onttoken)[\\\"']?[^>]*>");
    private static final Pattern VALUE_ATTR = Pattern.compile("(?i)\\bvalue\\s*=\\s*[\\\"']?([^\\\"'\\s>]+)");
    private static final Pattern TOKEN_FALLBACK = Pattern.compile("(?i)(?:hwonttoken|onttoken)[^>\\n]{0,180}?value\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern ENABLED = Pattern.compile("(?i)var\\s+(?:enableFilter|WlanMacFilterRight)\\s*=\\s*['\\\"]?(\\d)['\\\"]?");
    private static final Pattern MODE = Pattern.compile("(?i)var\\s+(?:Mode|WlanMacFilterPolicy)\\s*=\\s*['\\\"]?(\\d)['\\\"]?");
    private static final Pattern MAC_RE = Pattern.compile("(?i)^[0-9a-f]{2}(?::[0-9a-f]{2}){5}$");

    public HuaweiRouterClient(String host, String username, String password) {
        String h = host.trim();
        if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://" + h;
        while (h.endsWith("/")) h = h.substring(0, h.length() - 1);
        this.baseUrl = h;
        this.username = username;
        this.password = password;
        CookieHandler.setDefault(cookieManager);
    }

    public void login() throws Exception {
        request("GET", "/", null, null);
        String token = request("POST", "/asp/GetRandCount.asp", "", null).trim().replace("\uFEFF", "");
        if (token.isEmpty()) throw new IOException("توکن ورود از مودم دریافت نشد.");

        String pass64 = Base64.encodeToString(password.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        Map<String, String> f = new LinkedHashMap<>();
        f.put("UserName", username);
        f.put("PassWord", pass64);
        f.put("Language", "english");
        f.put("x.X_HW_Token", token);
        String html = request("POST", "/login.cgi", formEncode(f), baseUrl + "/");
        if (looksLikeLoginPage(html)) {
            throw new IOException("نام کاربری یا رمز مودم اشتباه است، یا ورود موقتاً قفل شده.");
        }
    }

    public List<Device> getDevices() throws Exception {
        String html = request("POST", DEVINFO_PATH, "", baseUrl + "/index.asp");
        if (looksLikeLoginPage(html)) throw new IOException("نشست ورود مودم منقضی شده است. دوباره اتصال بزن.");

        LinkedHashMap<String, Device> unique = new LinkedHashMap<>();
        Matcher m = DEVINFO_CALL.matcher(html);
        while (m.find()) {
            List<String> args = quotedArgs(m.group(1));
            if (args.size() < 9) continue;
            String name = args.get(0);
            String ip = args.get(2);
            String mac = args.get(3);
            String status = args.get(5);
            String iface = args.get(6);
            String connected = args.get(7);
            String key = (mac == null || mac.isEmpty()) ? name : mac.toLowerCase(Locale.ROOT);
            if (!unique.containsKey(key)) {
                unique.put(key, new Device(name, ip, mac, status, iface, connected));
            }
        }

        // Device listing must still work even if this firmware hides its MAC-filter page.
        try {
            MacFilterStatus fs = getMacFilterStatus();
            for (Device d : unique.values()) d.blocked = fs.containsMac(d.mac);
        } catch (Exception ignored) {
            for (Device d : unique.values()) d.blocked = false;
        }
        return new ArrayList<>(unique.values());
    }

    public MacFilterStatus getMacFilterStatus() throws Exception {
        Exception firstError = null;
        try {
            return readMacFilter(WLAN_MAC_FILTER_PATH, true);
        } catch (Exception e) {
            firstError = e;
        }
        try {
            return readMacFilter(LAN_MAC_FILTER_PATH, false);
        } catch (Exception e) {
            String a = firstError == null ? "" : firstError.getMessage();
            String b = e.getMessage();
            throw new IOException("صفحه MAC Filter این فریمور پیدا/خوانده نشد. WLAN: " + a + " | LAN: " + b);
        }
    }

    private MacFilterStatus readMacFilter(String path, boolean wlan) throws Exception {
        String html = request("GET", path, null, baseUrl + "/index.asp");
        if (looksLikeLoginPage(html)) throw new IOException("نشست ورود منقضی شده");

        String token = extractToken(html);
        boolean enabled = false;
        String mode = "blacklist";
        Matcher em = ENABLED.matcher(html);
        if (em.find()) enabled = "1".equals(em.group(1));
        Matcher mm = MODE.matcher(html);
        if (mm.find()) mode = "1".equals(mm.group(1)) ? "whitelist" : "blacklist";

        List<MacEntry> entries = new ArrayList<>();
        Matcher e = MAC_ENTRY.matcher(html);
        while (e.find()) {
            List<String> args = quotedArgs(e.group(1));
            if (args.isEmpty()) continue;
            String domain = decodeHex(args.get(0));
            String mac = "";
            String alias = "";
            for (int i = 1; i < args.size(); i++) {
                String v = decodeHex(args.get(i)).trim();
                if (MAC_RE.matcher(v).matches()) mac = v;
                else if (!v.isEmpty()) alias = v;
            }
            if (!domain.isEmpty() && !mac.isEmpty()) entries.add(new MacEntry(domain, mac, alias));
        }
        return new MacFilterStatus(enabled, mode, token, entries, path, wlan);
    }

    public void ensureBlacklistEnabled() throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        if (s.enabled && "blacklist".equals(s.mode)) return;

        Map<String, String> f = new LinkedHashMap<>();
        f.put(s.wlan ? "x.WlanMacFilterRight" : "x.MacFilterRight", "1");
        f.put(s.wlan ? "x.WlanMacFilterPolicy" : "x.MacFilterPolicy", "0");
        f.put("x.X_HW_Token", s.token);

        String folder = s.wlan ? "/html/bbsp/wlanmacfilter" : "/html/bbsp/macfilter";
        String url = folder + "/set.cgi?x=InternetGatewayDevice.X_HW_Security&RequestFile=" + s.path.substring(1);
        request("POST", url, formEncode(f), baseUrl + s.path);
    }

    public void block(Device d, String alias) throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        if (!s.enabled || !"blacklist".equals(s.mode)) {
            throw new IOException("MAC Filter باید در حالت Blacklist فعال باشد.");
        }
        if (s.containsMac(d.mac)) return;

        Map<String, String> f = new LinkedHashMap<>();
        f.put("x.SourceMACAddress", d.mac);
        if (s.wlan) {
            f.put("x.SSIDName", guessSsidName(d));
            f.put("x.Enable", "1");
        } else {
            f.put("x.DeviceAlias", alias == null ? "" : alias);
        }
        f.put("x.X_HW_Token", s.token);

        String folder = s.wlan ? "/html/bbsp/wlanmacfilter" : "/html/bbsp/macfilter";
        String domain = s.wlan ? "InternetGatewayDevice.X_HW_Security.WLANMacFilter" : "InternetGatewayDevice.X_HW_Security.MacFilter";
        String url = folder + "/add.cgi?x=" + domain + "&RequestFile=" + s.path.substring(1);
        request("POST", url, formEncode(f), baseUrl + s.path);
    }

    public void unblock(Device d) throws Exception {
        MacFilterStatus s = getMacFilterStatus();
        MacEntry found = null;
        for (MacEntry e : s.entries) {
            if (e.mac.equalsIgnoreCase(d.mac)) { found = e; break; }
        }
        if (found == null) return;

        Map<String, String> f = new LinkedHashMap<>();
        f.put(found.domain, "");
        f.put("x.X_HW_Token", s.token);

        String folder = s.wlan ? "/html/bbsp/wlanmacfilter" : "/html/bbsp/macfilter";
        String domain = s.wlan ? "InternetGatewayDevice.X_HW_Security.WLANMacFilter" : "InternetGatewayDevice.X_HW_Security.MacFilter";
        String url = folder + "/del.cgi?x=" + domain + "&RequestFile=" + s.path.substring(1);
        request("POST", url, formEncode(f), baseUrl + s.path);
    }

    private String guessSsidName(Device d) {
        // Most Huawei residential ONTs accept SSID-1 for the primary WLAN filter.
        // If the device-information interface already contains an SSID label, preserve it.
        String iface = d == null ? "" : d.iface;
        if (iface != null && iface.toUpperCase(Locale.ROOT).startsWith("SSID")) return iface;
        return "SSID-1";
    }

    private String request(String method, String path, String body, String referer) throws Exception {
        URL url = new URL(path.startsWith("http") ? path : baseUrl + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(12000);
        c.setRequestMethod(method);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*");
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        c.setRequestProperty("X-Requested-With", "XMLHttpRequest");
        if (referer != null) c.setRequestProperty("Referer", referer);
        if ("POST".equals(method)) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            byte[] bytes = (body == null ? "" : body).getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
        String text = readAll(is);
        c.disconnect();
        if (code < 200 || code >= 400) throw new IOException("HTTP " + code);
        return text;
    }

    private static boolean looksLikeLoginPage(String html) {
        if (html == null || html.isEmpty()) return false;
        String h = html.toLowerCase(Locale.ROOT);
        return (h.contains("txt_username") && h.contains("txt_password")) ||
                (h.contains("login.cgi") && h.contains("type=\"password\""));
    }

    private static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private static String formEncode(Map<String, String> map) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : map.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), "UTF-8"));
            sb.append('=');
            sb.append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }
        return sb.toString();
    }

    private static List<String> quotedArgs(String call) {
        ArrayList<String> out = new ArrayList<>();
        Matcher m = QUOTED.matcher(call);
        while (m.find()) out.add(decodeHex(m.group(1)));
        return out;
    }

    private static String decodeHex(String s) {
        Matcher m = HEX.matcher(s == null ? "" : s);
        StringBuffer b = new StringBuffer();
        while (m.find()) {
            char ch = (char) Integer.parseInt(m.group(1), 16);
            m.appendReplacement(b, Matcher.quoteReplacement(String.valueOf(ch)));
        }
        m.appendTail(b);
        return b.toString().replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private static String extractToken(String html) throws IOException {
        Matcher tag = INPUT_TAG.matcher(html == null ? "" : html);
        while (tag.find()) {
            Matcher v = VALUE_ATTR.matcher(tag.group());
            if (v.find() && !v.group(1).trim().isEmpty()) return v.group(1).trim();
        }
        Matcher f = TOKEN_FALLBACK.matcher(html == null ? "" : html);
        if (f.find() && !f.group(1).trim().isEmpty()) return f.group(1).trim();
        throw new IOException("توکن امنیتی در صفحه پیدا نشد");
    }

    public static class MacEntry {
        public final String domain, mac, alias;
        MacEntry(String domain, String mac, String alias) {
            this.domain = domain; this.mac = mac; this.alias = alias;
        }
    }

    public static class MacFilterStatus {
        public final boolean enabled;
        public final String mode;
        public final String token;
        public final List<MacEntry> entries;
        public final String path;
        public final boolean wlan;

        MacFilterStatus(boolean enabled, String mode, String token, List<MacEntry> entries, String path, boolean wlan) {
            this.enabled = enabled;
            this.mode = mode;
            this.token = token;
            this.entries = entries;
            this.path = path;
            this.wlan = wlan;
        }

        public boolean containsMac(String mac) {
            if (mac == null) return false;
            for (MacEntry e : entries) if (e.mac.equalsIgnoreCase(mac)) return true;
            return false;
        }
    }
}
