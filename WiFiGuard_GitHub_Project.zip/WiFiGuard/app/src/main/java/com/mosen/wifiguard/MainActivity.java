package com.mosen.wifiguard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements DeviceAdapter.Listener {
    private EditText host, user, pass;
    private Button connect, refresh;
    private ProgressBar progress;
    private TextView status;
    private ListView list;
    private DeviceAdapter adapter;
    private HuaweiRouterClient client;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("wifi_guard", MODE_PRIVATE);
        buildUi();
    }

    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F7FA);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(18), dp(18), dp(16));
        header.setBackgroundColor(0xFF0B1220);

        TextView title = new TextView(this);
        title.setText("WiFi Guard");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.RIGHT);
        header.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("مدیریت دستگاه‌های متصل به مودم Huawei");
        subtitle.setTextColor(0xFFB8C2D1);
        subtitle.setGravity(Gravity.RIGHT);
        header.addView(subtitle);
        root.addView(header);

        LinearLayout login = new LinearLayout(this);
        login.setOrientation(LinearLayout.VERTICAL);
        login.setPadding(dp(14), dp(12), dp(14), dp(8));
        host = field("آدرس مودم", prefs.getString("host", "192.168.100.1"), InputType.TYPE_CLASS_TEXT);
        user = field("نام کاربری", prefs.getString("user", "root"), InputType.TYPE_CLASS_TEXT);
        pass = field("رمز ورود مودم", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        login.addView(host); login.addView(user); login.addView(pass);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        connect = new Button(this); connect.setText("اتصال");
        refresh = new Button(this); refresh.setText("بروزرسانی"); refresh.setEnabled(false);
        progress = new ProgressBar(this); progress.setVisibility(View.GONE);
        bar.addView(progress, new LinearLayout.LayoutParams(dp(44), dp(44)));
        bar.addView(refresh); bar.addView(connect);
        login.addView(bar);
        root.addView(login);

        status = new TextView(this);
        status.setText("ابتدا رمز مدیریت مودم را وارد کن.");
        status.setTextColor(0xFF475467);
        status.setGravity(Gravity.RIGHT);
        status.setPadding(dp(18), dp(4), dp(18), dp(8));
        root.addView(status);

        list = new ListView(this);
        list.setDivider(null);
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, dp(18));
        adapter = new DeviceAdapter(this, prefs, this);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);

        connect.setOnClickListener(v -> connectRouter());
        refresh.setOnClickListener(v -> refreshDevices());
    }

    private EditText field(String hint, String text, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(text);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setGravity(Gravity.RIGHT);
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private void connectRouter() {
        String h = host.getText().toString().trim();
        String u = user.getText().toString().trim();
        String p = pass.getText().toString();
        if (h.isEmpty() || u.isEmpty() || p.isEmpty()) {
            Toast.makeText(this, "آدرس، نام کاربری و رمز را کامل کن.", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().putString("host", h).putString("user", u).apply();
        hideKeyboard();
        setBusy(true, "در حال اتصال به مودم…");
        executor.execute(() -> {
            try {
                HuaweiRouterClient c = new HuaweiRouterClient(h, u, p);
                c.login();
                List<Device> ds = c.getDevices();
                runOnUiThread(() -> {
                    client = c;
                    adapter.setItems(ds);
                    refresh.setEnabled(true);
                    setBusy(false, ds.size() + " دستگاه پیدا شد");
                });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
            }
        });
    }

    private void refreshDevices() {
        if (client == null) return;
        setBusy(true, "در حال بروزرسانی…");
        executor.execute(() -> {
            try {
                List<Device> ds = client.getDevices();
                runOnUiThread(() -> { adapter.setItems(ds); setBusy(false, ds.size() + " دستگاه پیدا شد"); });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
            }
        });
    }

    @Override
    public void onRename(Device d) {
        EditText input = new EditText(this);
        input.setGravity(Gravity.RIGHT);
        input.setSingleLine(true);
        input.setText(prefs.getString("alias_" + d.mac, d.routerName));
        new AlertDialog.Builder(this)
                .setTitle("نام دلخواه دستگاه")
                .setMessage("این نام داخل خود برنامه ذخیره می‌شود.")
                .setView(input)
                .setPositiveButton("ذخیره", (dialog, which) -> {
                    String v = input.getText().toString().trim();
                    prefs.edit().putString("alias_" + d.mac, v).apply();
                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("انصراف", null).show();
    }

    @Override
    public void onToggleBlock(Device d) {
        if (client == null) return;
        if (d.blocked) {
            confirm("رفع بلاک", "دسترسی این دستگاه دوباره فعال شود؟", () -> doUnblock(d));
        } else {
            confirm("بلاک دستگاه", "این دستگاه از دسترسی شبکه/اینترنت مسدود شود؟", () -> prepareAndBlock(d));
        }
    }

    private void prepareAndBlock(Device d) {
        setBusy(true, "در حال بررسی MAC Filter…");
        executor.execute(() -> {
            try {
                HuaweiRouterClient.MacFilterStatus s = client.getMacFilterStatus();
                if (s.enabled && "blacklist".equals(s.mode)) {
                    blockNow(d);
                } else {
                    runOnUiThread(() -> {
                        setBusy(false, "برای بلاک، Blacklist باید فعال شود.");
                        new AlertDialog.Builder(this)
                                .setTitle("فعال‌سازی Blacklist")
                                .setMessage("مودم الان MAC Filter را در حالت Blacklist ندارد. فعال‌کردن آن یک تنظیم سراسری مودم است. انجام شود؟")
                                .setPositiveButton("فعال کن", (x, y) -> {
                                    setBusy(true, "در حال فعال‌سازی Blacklist…");
                                    executor.execute(() -> {
                                        try { client.ensureBlacklistEnabled(); blockNow(d); }
                                        catch (Exception e) { runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage())); }
                                    });
                                })
                                .setNegativeButton("انصراف", null).show();
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
            }
        });
    }

    private void blockNow(Device d) {
        try {
            String alias = prefs.getString("alias_" + d.mac, d.routerName);
            client.block(d, alias);
            List<Device> ds = client.getDevices();
            runOnUiThread(() -> { adapter.setItems(ds); setBusy(false, "دستگاه بلاک شد."); });
        } catch (Exception e) {
            runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
        }
    }

    private void doUnblock(Device d) {
        setBusy(true, "در حال رفع بلاک…");
        executor.execute(() -> {
            try {
                client.unblock(d);
                List<Device> ds = client.getDevices();
                runOnUiThread(() -> { adapter.setItems(ds); setBusy(false, "بلاک برداشته شد."); });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
            }
        });
    }

    private void confirm(String title, String message, Runnable yes) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
                .setPositiveButton("بله", (d, w) -> yes.run())
                .setNegativeButton("خیر", null).show();
    }

    private void setBusy(boolean busy, String text) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        connect.setEnabled(!busy);
        refresh.setEnabled(!busy && client != null);
        status.setText(text);
    }

    private void hideKeyboard() {
        View v = getCurrentFocus();
        if (v != null) ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
