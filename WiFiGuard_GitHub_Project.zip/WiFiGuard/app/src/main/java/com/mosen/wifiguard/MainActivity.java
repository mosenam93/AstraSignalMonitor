package com.mosen.wifiguard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements DeviceAdapter.Listener {
    private static final int BG = 0xFF08111F;
    private static final int CARD = 0xFF111C2D;
    private static final int CARD_2 = 0xFF0D1726;
    private static final int BORDER = 0xFF24344F;
    private static final int TEXT = 0xFFF3F7FC;
    private static final int MUTED = 0xFF94A6BE;
    private static final int BLUE = 0xFF4AA3FF;
    private static final int GREEN = 0xFF28D17C;
    private static final int RED = 0xFFFF5A6A;

    private EditText host, user, pass;
    private LinearLayout credentialsBox;
    private Button connect, refresh;
    private ProgressBar progress;
    private TextView status, countBadge, sourceText;
    private ListView list;
    private DeviceAdapter adapter;
    private HuaweiRouterClient client;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler monitorHandler = new Handler(Looper.getMainLooper());
    private boolean trafficPollRunning = false;
    private static final long TRAFFIC_POLL_MS = 5000L;
    private SharedPreferences prefs;

    private final Runnable trafficMonitor = new Runnable() {
        @Override public void run() {
            if (client != null && !trafficPollRunning) pollTrafficSilently();
            monitorHandler.postDelayed(this, TRAFFIC_POLL_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("wifi_guard", MODE_PRIVATE);
        buildUi();
        monitorHandler.postDelayed(trafficMonitor, TRAFFIC_POLL_MS);
    }

    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable bg(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(15), dp(16), dp(15));
        c.setBackground(bg(CARD, 18, BORDER));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(16), dp(9), dp(16), dp(5));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(MUTED);
        t.setTextSize(12);
        t.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(5));
        t.setLayoutParams(lp);
        return t;
    }

    private void buildUi() {
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        header.setPadding(dp(20), dp(22), dp(20), dp(13));
        header.setBackgroundColor(BG);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_wifi_guard_logo);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(48), dp(48));
        llp.setMargins(0, 0, dp(12), 0);
        logo.setLayoutParams(llp);

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        titleWrap.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText("WiFi Guard");
        title.setTextColor(TEXT);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.RIGHT);
        titleWrap.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("مدیریت دستگاه‌های متصل به مودم Huawei");
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.RIGHT);
        subtitle.setPadding(0, dp(3), 0, 0);
        titleWrap.addView(subtitle);

        header.addView(logo);
        header.addView(titleWrap);
        root.addView(header);

        LinearLayout loginCard = card();
        TextView loginTitle = new TextView(this);
        loginTitle.setText("اتصال به مودم");
        loginTitle.setTextColor(TEXT);
        loginTitle.setTextSize(18);
        loginTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        loginTitle.setGravity(Gravity.RIGHT);
        loginCard.addView(loginTitle);

        credentialsBox = new LinearLayout(this);
        credentialsBox.setOrientation(LinearLayout.VERTICAL);
        credentialsBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        credentialsBox.addView(label("آدرس مودم"));
        host = field(prefs.getString("host", "192.168.100.1"), InputType.TYPE_CLASS_TEXT);
        credentialsBox.addView(host);

        credentialsBox.addView(label("نام کاربری"));
        user = field(prefs.getString("user", "root"), InputType.TYPE_CLASS_TEXT);
        credentialsBox.addView(user);

        credentialsBox.addView(label("رمز ورود مودم"));
        pass = field(prefs.getString("pass", "admin"), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.setHint("admin");
        credentialsBox.addView(pass);
        loginCard.addView(credentialsBox);

        LinearLayout buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams brlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brlp.setMargins(0, dp(14), 0, 0);
        buttonRow.setLayoutParams(brlp);

        connect = actionButton("اتصال و نمایش دستگاه‌ها", BLUE, Color.WHITE);
        refresh = actionButton("بروزرسانی", 0xFF1D2B42, TEXT);
        refresh.setEnabled(false);
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);

        buttonRow.addView(connect, new LinearLayout.LayoutParams(0, dp(48), 1.35f));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(dp(8), 1);
        buttonRow.addView(new View(this), gap);
        buttonRow.addView(refresh, new LinearLayout.LayoutParams(0, dp(48), 0.9f));
        buttonRow.addView(progress, new LinearLayout.LayoutParams(dp(44), dp(44)));
        loginCard.addView(buttonRow);
        root.addView(loginCard);

        LinearLayout stateCard = card();
        stateCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout stateRow = new LinearLayout(this);
        stateRow.setOrientation(LinearLayout.HORIZONTAL);
        stateRow.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);

        countBadge = new TextView(this);
        countBadge.setText("0 دستگاه");
        countBadge.setTextColor(TEXT);
        countBadge.setTextSize(13);
        countBadge.setGravity(Gravity.CENTER);
        countBadge.setPadding(dp(13), dp(8), dp(13), dp(8));
        countBadge.setBackground(bg(0xFF182840, 20, BORDER));
        stateRow.addView(countBadge);

        TextView sectionTitle = new TextView(this);
        sectionTitle.setText("  دستگاه‌های متصل");
        sectionTitle.setTextColor(TEXT);
        sectionTitle.setTextSize(17);
        sectionTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        sectionTitle.setGravity(Gravity.RIGHT);
        stateRow.addView(sectionTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        stateCard.addView(stateRow);

        status = new TextView(this);
        status.setText("ابتدا رمز مدیریت مودم را وارد کن.");
        status.setTextColor(0xFFC7D4E5);
        status.setTextSize(13);
        status.setGravity(Gravity.RIGHT);
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.setMargins(0, dp(10), 0, 0);
        status.setLayoutParams(slp);
        status.setBackground(bg(0xFF152238, 12, BORDER));
        stateCard.addView(status);

        sourceText = new TextView(this);
        sourceText.setText("منبع لیست: هنوز متصل نشده");
        sourceText.setTextColor(MUTED);
        sourceText.setTextSize(11);
        sourceText.setGravity(Gravity.RIGHT);
        sourceText.setPadding(dp(2), dp(8), dp(2), 0);
        stateCard.addView(sourceText);
        root.addView(stateCard);

        FrameLayout listFrame = new FrameLayout(this);
        list = new ListView(this);
        list.setDivider(null);
        list.setClipToPadding(false);
        list.setPadding(dp(4), dp(5), dp(4), dp(24));
        list.setBackgroundColor(Color.TRANSPARENT);
        adapter = new DeviceAdapter(this, prefs, this);
        list.setAdapter(adapter);
        listFrame.addView(list, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView empty = new TextView(this);
        empty.setText("هنوز دستگاهی نمایش داده نشده\nبعد از اتصال، گوشی‌ها و دستگاه‌های شبکه اینجا دیده می‌شوند.");
        empty.setTextColor(MUTED);
        empty.setTextSize(14);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(30), dp(40), dp(30), dp(30));
        listFrame.addView(empty, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        list.setEmptyView(empty);

        root.addView(listFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);

        connect.setOnClickListener(v -> connectRouter());
        refresh.setOnClickListener(v -> refreshDevices());
    }

    private EditText field(String text, int inputType) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(TEXT);
        e.setHintTextColor(0xFF61738E);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        e.setPadding(dp(13), 0, dp(13), 0);
        e.setBackground(bg(CARD_2, 13, BORDER));
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        return e;
    }

    private Button actionButton(String text, int color, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setBackground(bg(color, 13, color));
        return b;
    }

    private void connectRouter() {
        String h = host.getText().toString().trim();
        String u = user.getText().toString().trim();
        String p = pass.getText().toString();
        if (h.isEmpty() || u.isEmpty() || p.isEmpty()) {
            Toast.makeText(this, "آدرس، نام کاربری و رمز را کامل کن.", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().putString("host", h).putString("user", u).putString("pass", p).apply();
        hideKeyboard();
        setBusy(true, "در حال اتصال و خواندن دستگاه‌ها…");
        executor.execute(() -> {
            try {
                HuaweiRouterClient c = new HuaweiRouterClient(h, u, p);
                c.login();
                List<Device> ds = c.getDevices();
                applyUsageAccounting(ds);
                runOnUiThread(() -> {
                    client = c;
                    adapter.setItems(ds);
                    updateDeviceSummary(ds.size(), c.getLastDeviceSource());
                    credentialsBox.setVisibility(View.GONE);
                    connect.setText("اتصال برقرار ✓");
                    setBusy(false, ds.isEmpty() ? "ورود موفق بود، اما هنوز دستگاهی از مودم دریافت نشد." : "اتصال برقرار است و لیست دستگاه‌ها بروزرسانی شد.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    credentialsBox.setVisibility(View.VISIBLE);
                    connect.setText("اتصال و نمایش دستگاه‌ها");
                    setBusy(false, "خطا: " + e.getMessage());
                });
            }
        });
    }

    private void refreshDevices() {
        if (client == null) return;
        setBusy(true, "در حال بروزرسانی لیست…");
        executor.execute(() -> {
            try {
                // HG8546M sometimes returns an empty device snapshot for a moment
                // while it rebuilds User Device Information. Retry before touching
                // the visible list, then renew the login once as a last recovery.
                List<Device> ds = client.getDevices();
                if (ds.isEmpty()) {
                    Thread.sleep(650);
                    ds = client.getDevices();
                }
                if (ds.isEmpty()) {
                    Thread.sleep(650);
                    ds = client.getDevices();
                }
                if (ds.isEmpty()) {
                    try {
                        client.login();
                        Thread.sleep(350);
                        ds = client.getDevices();
                    } catch (Exception ignored) {
                        // Keep the existing list if recovery login fails; a transient
                        // empty router response must never erase a good on-screen list.
                    }
                }

                // Manual Refresh must refresh usage too. Ask the dedicated
                // traffic feed for the newest RX/TX values and copy them onto
                // the freshly-read device rows before updating the local usage
                // counters. If this firmware has no traffic feed, the normal
                // device refresh still succeeds.
                try {
                    List<Device> traffic = client.getTrafficSnapshot();
                    mergeTrafficFields(ds, traffic);
                } catch (Exception ignored) {}

                applyUsageAccounting(ds);
                final List<Device> fresh = ds;
                runOnUiThread(() -> {
                    if (fresh.isEmpty() && adapter.getCount() > 0) {
                        // Do not flash the UI to 0 devices when the modem gives a
                        // temporary empty snapshot. The next refresh can replace it.
                        updateDeviceSummary(adapter.getCount(), client.getLastDeviceSource());
                        setBusy(false, "مودم موقتاً لیست خالی برگرداند؛ لیست قبلی حفظ شد.");
                    } else {
                        adapter.setItems(fresh);
                        updateDeviceSummary(fresh.size(), client.getLastDeviceSource());
                        setBusy(false, fresh.isEmpty() ? "هنوز دستگاهی دریافت نشد." : "لیست بروزرسانی شد.");
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
            }
        });
    }

    private void mergeTrafficFields(List<Device> devices, List<Device> traffic) {
        if (devices == null || traffic == null || traffic.isEmpty()) return;
        for (Device d : devices) {
            String mac = safeMac(d.mac);
            if (mac.isEmpty()) continue;
            for (Device t : traffic) {
                if (!mac.equalsIgnoreCase(safeMac(t.mac))) continue;
                d.rxRate = t.rxRate;
                d.txRate = t.txRate;
                if (t.status != null && !t.status.trim().isEmpty()) d.status = t.status;
                if (t.connectedTime != null && !t.connectedTime.trim().isEmpty()) d.connectedTime = t.connectedTime;
                break;
            }
        }
    }

    private void updateDeviceSummary(int count, String source) {
        countBadge.setText(count + " دستگاه");
        countBadge.setBackground(bg(count > 0 ? 0xFF123B2B : 0xFF182840, 20, count > 0 ? 0xFF1E6A49 : BORDER));
        countBadge.setTextColor(count > 0 ? 0xFF7DF0B3 : TEXT);
        sourceText.setText("منبع لیست: " + (source == null || source.isEmpty() ? "نامشخص" : source));
    }

    @Override
    public void onRename(Device d) {
        EditText input = field(prefs.getString("alias_" + d.mac, d.routerName), InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this)
                .setTitle("نام دلخواه دستگاه")
                .setMessage("این نام فقط داخل WiFi Guard ذخیره می‌شود و اسم دستگاه در مودم را تغییر نمی‌دهد.")
                .setView(input)
                .setPositiveButton("ذخیره", (dialog, which) -> {
                    String v = input.getText().toString().trim();
                    prefs.edit().putString("alias_" + d.mac, v).apply();
                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("انصراف", null).show();
    }

    @Override
    public void onUsage(Device d) {
        String mac = safeMac(d.mac);
        if (mac.isEmpty()) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), 0);

        TextView info = new TextView(this);
        info.setTextColor(MUTED);
        info.setTextSize(13);
        info.setGravity(Gravity.RIGHT);
        String used = formatBytes(d.usedBytesThisMonth);
        String left = d.quotaBytes > 0 ? formatBytes(Math.max(0L, d.quotaBytes - d.usedBytesThisMonth)) : "نامحدود";
        info.setText("مصرف ثبت‌شده این ماه: " + used + "\nباقیمانده: " + left +
                "\n\nحجم ماهانه را به GB وارد کن. عدد 0 یعنی بدون سقف.\nمصرف این نسخه تخمینی است و هنگام فعال بودن مانیتور WiFi Guard محاسبه می‌شود.");
        box.addView(info);

        EditText quota = field(d.quotaBytes > 0 ? String.format(Locale.US, "%.2f", d.quotaBytes / 1_000_000_000.0) : "",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        quota.setHint("مثلاً 20");
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        qlp.setMargins(0, dp(12), 0, 0);
        quota.setLayoutParams(qlp);
        box.addView(quota);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("حجم ماهانه دستگاه")
                .setView(box)
                .setPositiveButton("ذخیره", null)
                .setNeutralButton("صفر کردن مصرف", null)
                .setNegativeButton("انصراف", null)
                .create();

        dialog.setOnShowListener(x -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String raw = quota.getText().toString().trim().replace(',', '.');
                double gb = 0;
                try { if (!raw.isEmpty()) gb = Math.max(0, Double.parseDouble(raw)); }
                catch (Exception e) {
                    Toast.makeText(this, "حجم را به عدد وارد کن.", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.edit().putString("quota_gb_" + mac, String.format(Locale.US, "%.4f", gb)).apply();
                d.quotaBytes = (long)(gb * 1_000_000_000L);
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                prefs.edit().putLong(usageKey(mac), 0L).remove("usage_prev_rate_" + mac).remove("usage_prev_ts_" + mac).apply();
                d.usedBytesThisMonth = 0L;
                adapter.notifyDataSetChanged();
                Toast.makeText(this, "مصرف ثبت‌شده این ماه صفر شد.", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private void pollTrafficSilently() {
        if (client == null || trafficPollRunning) return;
        trafficPollRunning = true;
        executor.execute(() -> {
            try {
                List<Device> snapshot = client.getTrafficSnapshot();
                if (!snapshot.isEmpty()) {
                    applyUsageAccounting(snapshot);
                    runOnUiThread(() -> adapter.mergeTraffic(snapshot));
                }
            } catch (Exception ignored) {
                // Live monitoring is best-effort; a missed sample must not turn
                // into a visible connection error or erase the current list.
            } finally {
                trafficPollRunning = false;
            }
        });
    }

    private void applyUsageAccounting(List<Device> devices) {
        if (devices == null) return;
        long now = System.currentTimeMillis();
        SharedPreferences.Editor edit = prefs.edit();

        for (Device d : devices) {
            String mac = safeMac(d.mac);
            if (mac.isEmpty()) continue;

            long rx = parseRateBytesPerSecond(d.rxRate);
            long tx = parseRateBytesPerSecond(d.txRate);
            long currentRate = Math.max(0L, rx) + Math.max(0L, tx);
            d.liveRateBytesPerSecond = currentRate;

            long used = prefs.getLong(usageKey(mac), 0L);
            long previousTs = prefs.getLong("usage_prev_ts_" + mac, 0L);
            long previousRate = prefs.getLong("usage_prev_rate_" + mac, currentRate);

            long dtMs = previousTs > 0 ? now - previousTs : 0L;
            // Only integrate nearby samples. We deliberately do not multiply a
            // stale rate by hours spent with the app closed.
            if (dtMs >= 1000L && dtMs <= 30_000L) {
                double seconds = dtMs / 1000.0;
                long averageRate = (previousRate + currentRate) / 2L;
                if (averageRate > 0) used += (long)(averageRate * seconds);
            }

            double quotaGb = 0;
            try { quotaGb = Double.parseDouble(prefs.getString("quota_gb_" + mac, "0")); }
            catch (Exception ignored) {}

            d.usedBytesThisMonth = used;
            d.quotaBytes = quotaGb > 0 ? (long)(quotaGb * 1_000_000_000L) : 0L;

            edit.putLong(usageKey(mac), used);
            edit.putLong("usage_prev_ts_" + mac, now);
            edit.putLong("usage_prev_rate_" + mac, currentRate);
        }
        edit.apply();
    }

    private String usageKey(String mac) {
        String month = new SimpleDateFormat("yyyyMM", Locale.US).format(new Date());
        return "usage_" + month + "_" + mac;
    }

    private static String safeMac(String mac) {
        return mac == null ? "" : mac.trim().toUpperCase(Locale.ROOT);
    }

    private static long parseRateBytesPerSecond(String raw) {
        if (raw == null) return 0L;
        String v = raw.trim().toUpperCase(Locale.ROOT).replace("/S", "").replace("PS", "").trim();
        if (v.isEmpty() || v.equals("--")) return 0L;
        try {
            String num = v.replaceAll("[^0-9.]", "");
            if (num.isEmpty()) return 0L;
            double n = Double.parseDouble(num);
            if (v.contains("GBIT") || v.contains("GBPS")) return (long)(n * 1_000_000_000.0 / 8.0);
            if (v.contains("MBIT") || v.contains("MBPS")) return (long)(n * 1_000_000.0 / 8.0);
            if (v.contains("KBIT") || v.contains("KBPS")) return (long)(n * 1_000.0 / 8.0);
            if (v.contains("GB")) return (long)(n * 1024.0 * 1024.0 * 1024.0);
            if (v.contains("MB")) return (long)(n * 1024.0 * 1024.0);
            if (v.contains("KB")) return (long)(n * 1024.0);
            return (long)n; // HG user-device rate fields are numeric bytes/s.
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        if (bytes < 1_000_000_000L) return String.format(Locale.US, "%.1f MB", bytes / 1_000_000.0);
        return String.format(Locale.US, "%.2f GB", bytes / 1_000_000_000.0);
    }

    @Override
    public void onToggleBlock(Device d) {
        if (client == null) return;
        if (d.blocked) {
            confirm("رفع بلاک", "دسترسی این دستگاه دوباره فعال شود؟", () -> doUnblock(d));
        } else {
            confirm("بلاک دستگاه", "این دستگاه با MAC زیر مسدود شود؟\n" + d.mac, () -> prepareAndBlock(d));
        }
    }

    private void prepareAndBlock(Device d) {
        setBusy(true, "در حال بررسی MAC Filter…");
        executor.execute(() -> {
            try {
                HuaweiRouterClient.MacFilterStatus s = client.getMacFilterStatus();
                if (s.enabled && "blacklist".equals(s.mode)) {
                    blockNow(d);
                } else {
                    runOnUiThread(() -> {
                        setBusy(false, "برای بلاک، Blacklist باید فعال باشد.");
                        new AlertDialog.Builder(this)
                                .setTitle("فعال‌سازی Blacklist")
                                .setMessage("MAC Filter مودم در حالت Blacklist نیست. فعال‌کردن آن یک تنظیم سراسری مودم است. انجام شود؟")
                                .setPositiveButton("فعال کن", (x, y) -> {
                                    setBusy(true, "در حال فعال‌سازی Blacklist…");
                                    executor.execute(() -> {
                                        try { client.ensureBlacklistEnabled(); blockNow(d); }
                                        catch (Exception e) { runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage())); }
                                    });
                                })
                                .setNegativeButton("انصراف", null).show();
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
            }
        });
    }

    private void blockNow(Device d) {
        try {
            String alias = prefs.getString("alias_" + d.mac, d.routerName);
            client.block(d, alias);
            List<Device> ds = client.getDevices();
            applyUsageAccounting(ds);
            runOnUiThread(() -> {
                adapter.setItems(ds);
                updateDeviceSummary(ds.size(), client.getLastDeviceSource());
                setBusy(false, "دستگاه بلاک شد.");
            });
        } catch (Exception e) {
            runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
        }
    }

    private void doUnblock(Device d) {
        setBusy(true, "در حال رفع بلاک…");
        executor.execute(() -> {
            try {
                client.unblock(d);
                List<Device> ds = client.getDevices();
                applyUsageAccounting(ds);
                runOnUiThread(() -> {
                    adapter.setItems(ds);
                    updateDeviceSummary(ds.size(), client.getLastDeviceSource());
                    setBusy(false, "بلاک برداشته شد.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "خطا: " + e.getMessage()));
            }
        });
    }

    private void confirm(String title, String message, Runnable yes) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
                .setPositiveButton("بله", (d, w) -> yes.run())
                .setNegativeButton("خیر", null).show();
    }

    private void setBusy(boolean busy, String text) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        connect.setEnabled(!busy);
        refresh.setEnabled(!busy && client != null);
        status.setText(text);
        if (text != null && text.startsWith("خطا")) {
            status.setTextColor(0xFFFFA2AA);
            status.setBackground(bg(0xFF3B1B25, 12, 0xFF632636));
        } else if (!busy && client != null) {
            status.setTextColor(0xFF98F0BF);
            status.setBackground(bg(0xFF123425, 12, 0xFF20563C));
        } else {
            status.setTextColor(0xFFC7D4E5);
            status.setBackground(bg(0xFF152238, 12, BORDER));
        }
    }

    private void hideKeyboard() {
        View v = getCurrentFocus();
        if (v != null) ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    @Override protected void onDestroy() {
        monitorHandler.removeCallbacks(trafficMonitor);
        executor.shutdownNow();
        super.onDestroy();
    }
}
